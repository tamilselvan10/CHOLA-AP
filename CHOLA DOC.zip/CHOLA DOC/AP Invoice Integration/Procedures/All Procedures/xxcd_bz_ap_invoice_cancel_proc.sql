create or replace PROCEDURE xxcd_bz_ap_invoice_cancel_proc (errbuf OUT VARCHAR2,retcode OUT VARCHAR2,p_from_date IN VARCHAR2,p_to_date IN VARCHAR2)
AS

lv_total   NUMBER:=0;
lv_success NUMBER:=0;
lv_failure NUMBER:=0;


BEGIN

fnd_file.put_line(fnd_file.output,'
<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
  <Author>Tamilselvan.E</Author>
  <LastAuthor>Tamilselvan.E</LastAuthor>
  <Created>2022-10-17T12:10:54Z</Created>
  <Version>16.00</Version>
 </DocumentProperties>
 <OfficeDocumentSettings xmlns="urn:schemas-microsoft-com:office:office">
  <AllowPNG/>
 </OfficeDocumentSettings>
 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
  <WindowHeight>7050</WindowHeight>
  <WindowWidth>20490</WindowWidth>
  <WindowTopX>0</WindowTopX>
  <WindowTopY>0</WindowTopY>
  <ProtectStructure>False</ProtectStructure>
  <ProtectWindows>False</ProtectWindows>
 </ExcelWorkbook>
 <Styles>
  <Style ss:ID="Default" ss:Name="Normal">
   <Alignment ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>
   <Interior/>
   <NumberFormat/>
   <Protection/>
  </Style>
  <Style ss:ID="s66">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="26" ss:Color="#000000"/>
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s71">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Interior ss:Color="#B4C6E7" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s75">
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"
    ss:Bold="1"/>
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s76">
   <NumberFormat ss:Format="Short Date"/>
  </Style>
  <Style ss:ID="s82">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="16" ss:Color="#000000"
    ss:Bold="1"/>
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s87">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"
    ss:Bold="1"/>
   <Interior ss:Color="#BDD7EE" ss:Pattern="Solid"/>
  </Style>
 </Styles>');

 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Detail">
  <Table ss:ExpandedColumnCount="8" ss:ExpandedRowCount="7" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="68.25" ss:DefaultRowHeight="15">
   <Column ss:Index="8" ss:AutoFitWidth="0" ss:Width="248.25"/>
   <Row ss:Index="7" ss:Height="33.75">
    <Cell ss:Index="4" ss:MergeAcross="4" ss:StyleID="s66"><Data ss:Type="String">BAZ - Oracle EBS AP Invoice Cancellation Report</Data></Cell>
   </Row>
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Selected/>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>12</ActiveRow>
     <ActiveCol>8</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');

 --- Invoice Cancellation Sheet:
  fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Invoice Cancellation">
  <Table ss:ExpandedColumnCount="100" ss:ExpandedRowCount="10000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="108" ss:DefaultRowHeight="15">
   <Column ss:Index="2" ss:AutoFitWidth="0" ss:Width="115.5"/>
   <Column ss:AutoFitWidth="0" ss:Width="322.5"/>
   <Column ss:AutoFitWidth="0" ss:Width="139.5"/>
   <Column ss:Index="7" ss:AutoFitWidth="0" ss:Width="121.5"/>
   <Row ss:Index="3">
    <Cell ss:StyleID="s75"><Data ss:Type="String">Purpose</Data></Cell>
    <Cell><Data ss:Type="String">AP Invoice Cancellation</Data></Cell>
   </Row>
   <Row ss:Index="5">
    <Cell ss:StyleID="s71"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s71"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s71"><Data ss:Type="String">Operating Unit </Data></Cell>
    <Cell ss:StyleID="s71"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s71"><Data ss:Type="String">Vendor Site Name</Data></Cell>
    <Cell ss:StyleID="s71"><Data ss:Type="String">Invoice Number</Data></Cell>
    <Cell ss:StyleID="s71"><Data ss:Type="String">Action</Data></Cell>
    <Cell ss:StyleID="s71"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s71"><Data ss:Type="String">Last Update Date</Data></Cell>
    <Cell ss:StyleID="s71"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s71"><Data ss:Type="String">Error Message</Data></Cell>
   </Row>');

   FOR i IN (SELECT * FROM XXCD_BZ_AP_INVOICE_CANCEL_TB WHERE 1=1 AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss'))
   LOOP
    fnd_file.put_line(fnd_file.output,'
   <Row>
    <Cell><Data ss:Type="String">'||i.data_source||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||i.record_id||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.operating_unit||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.vendor_name||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.vendor_site_name||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.invoice_number||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.action||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.creation_date||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.last_update_date||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.status||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.error_message||'</Data></Cell>
   </Row>');
    END LOOP;

    fnd_file.put_line(fnd_file.output,'
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>5</ActiveRow>
     <ActiveCol>11</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');

 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Summary">
  <Table ss:ExpandedColumnCount="6" ss:ExpandedRowCount="7" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="86.25" ss:DefaultRowHeight="15">
   <Column ss:Index="3" ss:AutoFitWidth="0" ss:Width="104.25"/>
   <Column ss:AutoFitWidth="0" ss:Width="117.75"/>
   <Column ss:AutoFitWidth="0" ss:Width="114"/>
   <Row ss:Index="4" ss:Height="21">
    <Cell ss:Index="3" ss:MergeAcross="3" ss:StyleID="s82"><Data ss:Type="String">Oracle EBS - BAZ AP Invoice Cancellation Summary Report</Data></Cell>
   </Row>
   <Row ss:Index="6">
    <Cell ss:Index="3" ss:StyleID="s87"><Data ss:Type="String">Total Records</Data></Cell>
    <Cell ss:StyleID="s87"><Data ss:Type="String">Total Success Records</Data></Cell>
    <Cell ss:StyleID="s87"><Data ss:Type="String">Total Failure records</Data></Cell>
   </Row>');


   lv_total :=0;
   BEGIN
   SELECT COUNT(*) INTO lv_total FROM xxcd_bz_ap_invoice_cancel_tb WHERE 1=1 AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss');
   EXCEPTION WHEN OTHERS THEN
   lv_total:=0;
   END;

   lv_success:=0;
   BEGIN
   SELECT COUNT(*) INTO lv_success FROM xxcd_bz_ap_invoice_cancel_tb WHERE 1=1 AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status='SUCCESS';
   EXCEPTION WHEN OTHERS THEN
   lv_success:=0;
   END;

   lv_failure:=0;
   BEGIN
   SELECT COUNT(*) INTO lv_failure FROM xxcd_bz_ap_invoice_cancel_tb WHERE 1=1 AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status!='SUCCESS';
   EXCEPTION WHEN OTHERS THEN
   lv_failure:=0;
   END;


   fnd_file.put_line(fnd_file.output,'
   <Row>
    <Cell ss:Index="3"><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_success||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_failure||'</Data></Cell>
   </Row>
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>4</ActiveRow>
     <RangeSelection>R5</RangeSelection>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');

 fnd_file.put_line(fnd_file.output,'</Workbook>');

 EXCEPTION WHEN OTHERS THEN
 apps.fnd_file.put_line(apps.fnd_file.LOG,'Error Occured While executing the BAZ - Oracle EBS AP Invoice Cancellation Details Report');
 apps.fnd_file.put_line(apps.fnd_file.LOG,'Error Code  :'||SQLCODE);
 apps.fnd_file.put_line(apps.fnd_file.LOG,'Error Message:'||SQLERRM);
 END xxcd_bz_ap_invoice_cancel_proc;