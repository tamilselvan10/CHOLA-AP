create or replace procedure xxcd_bz_ap_inv_holds_rel_proc(errbuf OUT VARCHAR2,retcode OUT VARCHAR2,p_from_date IN VARCHAR2,p_to_date IN VARCHAR2)
as

lv_total   NUMBER:=0;
lv_success NUMBER:=0;
lv_failure NUMBER:=0;

lv_invoice_hold    NUMBER:=0;
lv_invoice_release NUMBER:=0;

BEGIN

fnd_file.put_line(fnd_file.output,'
<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
  <Author>Tamilselvan.E</Author>
  <LastAuthor>Tamilselvan.E</LastAuthor>
  <Created>2022-10-12T00:35:13Z</Created>
  <LastSaved>2022-10-12T00:45:40Z</LastSaved>
  <Version>16.00</Version>
 </DocumentProperties>
 <OfficeDocumentSettings xmlns="urn:schemas-microsoft-com:office:office">
  <AllowPNG/>
 </OfficeDocumentSettings>
 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
  <WindowHeight>7050</WindowHeight>
  <WindowWidth>20490</WindowWidth>
  <WindowTopX>0</WindowTopX>
  <WindowTopY>0</WindowTopY>
  <ActiveSheet>2</ActiveSheet>
  <ProtectStructure>False</ProtectStructure>
  <ProtectWindows>False</ProtectWindows>
 </ExcelWorkbook>
 <Styles>
  <Style ss:ID="Default" ss:Name="Normal">
   <Alignment ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>
   <Interior/>
   <NumberFormat/>
   <Protection/>
  </Style>
  <Style ss:ID="s67">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="14" ss:Color="#000000"
    ss:Bold="1"/>
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s73">
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s77">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Interior ss:Color="#8EA9DB" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s78">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Interior ss:Color="#B4C6E7" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s81">
   <NumberFormat ss:Format="Short Date"/>
  </Style>
  <Style ss:ID="s91">
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="18" ss:Color="#000000"/>
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
 </Styles>');

 --- Sheet1: Report
 fnd_file.put_line(fnd_file.output,'
<Worksheet ss:Name="Report">
  <Table ss:ExpandedColumnCount="13" ss:ExpandedRowCount="6" x:FullColumns="1"
   x:FullRows="1" ss:DefaultRowHeight="15">
   <Row ss:Index="6" ss:Height="18.75">
    <Cell ss:Index="5" ss:MergeAcross="8" ss:StyleID="s67"><Data ss:Type="String">BAZ - Oracle EBS AP Invoice Hold and Releases Report</Data></Cell>
   </Row>
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>11</ActiveRow>
     <ActiveCol>9</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');

  --- Sheet2: Invoice Holds and Releases
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Invoice Holds and Releases">
  <Table ss:ExpandedColumnCount="100" ss:ExpandedRowCount="10000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultRowHeight="15">
   <Column ss:AutoFitWidth="0" ss:Width="325.5"/>
   <Column ss:AutoFitWidth="0" ss:Width="145.5"/>
   <Column ss:AutoFitWidth="0" ss:Width="80.25"/>
   <Column ss:AutoFitWidth="0" ss:Width="95.25"/>
   <Column ss:AutoFitWidth="0" ss:Width="126"/>
   <Column ss:AutoFitWidth="0" ss:Width="119.25"/>
   <Column ss:AutoFitWidth="0" ss:Width="207.75"/>
   <Column ss:AutoFitWidth="0" ss:Width="202.5"/>
   <Column ss:AutoFitWidth="0" ss:Width="110.25"/>
   <Column ss:AutoFitWidth="0" ss:Width="75"/>
   <Column ss:AutoFitWidth="0" ss:Width="105.75"/>
   <Column ss:Index="13" ss:AutoFitWidth="0" ss:Width="68.25"/>
   <Row ss:Index="3">
    <Cell ss:StyleID="s73"><Data ss:Type="String">Purpose</Data></Cell>
    <Cell><Data ss:Type="String">AP invoice hold and Releases</Data></Cell>
   </Row>
   <Row ss:Index="5">
    <Cell ss:StyleID="s78"><Data ss:Type="String">Data Source</Data></Cell>
	<Cell ss:StyleID="s78"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Operating unit</Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Invoice Number</Data></Cell>
	<Cell ss:StyleID="s78"><Data ss:Type="String">Vendor Name</Data></Cell>
	<Cell ss:StyleID="s78"><Data ss:Type="String">Vendor Site Name</Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Hold Lookup Code</Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Hold Type</Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Hold Reason</Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Release Lookup Code</Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Release Reason</Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Action</Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Last Update Date</Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Status </Data></Cell>
    <Cell ss:StyleID="s78"><Data ss:Type="String">Error Message</Data></Cell>
   </Row>');

   FOR i IN (SELECT a.* FROM xxcd_bz_ap_invoice_holds_tb a WHERE 1=1 AND TRUNC(a.creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') ORDER by a.record_id DESC)
   LOOP
   fnd_file.put_line(fnd_file.output,'
   <Row>
    <Cell><Data ss:Type="String">'||i.data_source||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.record_id||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.operating_unit||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.invoice_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_site_name||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.hold_lookup_code||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.hold_type||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.hold_reason||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.release_lookup_code||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.release_reason||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.action||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.creation_date||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.last_update_date||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.status||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.error_message||'</Data></Cell>
   </Row>');
   END LOOP;   

   fnd_file.put_line(fnd_file.output,'</Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>17</ActiveRow>
     <ActiveCol>1</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');

 --- Sheet3: Summary
 fnd_file.put_line(fnd_file.output,'
  <Worksheet ss:Name="Summary">
  <Table ss:ExpandedColumnCount="100" ss:ExpandedRowCount="1000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultRowHeight="15">
   <Column ss:Index="5" ss:AutoFitWidth="0" ss:Width="105.75"/>
   <Column ss:AutoFitWidth="0" ss:Width="231.75"/>
   <Column ss:AutoFitWidth="0" ss:Width="208.5"/>
   <Row ss:Index="3" ss:Height="23.25">
    <Cell ss:Index="5" ss:StyleID="s91"><Data ss:Type="String">Summary:</Data></Cell>
   </Row>
   <Row ss:Index="5">
    <Cell ss:Index="5" ss:StyleID="s77"><Data ss:Type="String">Total No.of.Record</Data></Cell>
    <Cell ss:StyleID="s77"><Data ss:Type="String">Total Success Records</Data></Cell>
    <Cell ss:StyleID="s77"><Data ss:Type="String">Total Failure Records</Data></Cell>
   </Row>');

   lv_total:=0;

   BEGIN
   SELECT COUNT(*) INTO lv_total FROM xxcd_bz_ap_invoice_holds_tb WHERE 1=1 AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss');
   EXCEPTION WHEN OTHERS THEN
   lv_total:=0;
   END;
   -----------------------------------------------------------
   lv_success:=0;

   BEGIN
   SELECT COUNT(*) INTO lv_success FROM xxcd_bz_ap_invoice_holds_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND STATUS='SUCCESS';
   EXCEPTION WHEN OTHERS THEN
   lv_success:=0;
   END;
   -----------------------------------------------------------
   lv_failure:=0;

   BEGIN
   SELECT COUNT(*) INTO lv_failure FROM xxcd_bz_ap_invoice_holds_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND STATUS!='SUCCESS';
   EXCEPTION WHEN OTHERS THEN
   lv_failure:=0;
   END;
   --------------------------------------------------------------
   fnd_file.put_line(fnd_file.output,'
   <Row>
    <Cell ss:Index="5"><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_success||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_failure||'</Data></Cell>
   </Row>');

   /*

   fnd_file.put_line(fnd_file.output,'
   <Row ss:Index="10">
    <Cell ss:Index="5" ss:StyleID="s77"><Data ss:Type="String">Total No.of.Invoices</Data></Cell>
    <Cell ss:StyleID="s77"><Data ss:Type="String">Total.No.of.Invoices on-hold</Data></Cell>
    <Cell ss:StyleID="s77"><Data ss:Type="String">Total No.of.Invoices Hold released</Data></Cell>
   </Row>');

    -----------------------------------------------------------
   lv_invoice_hold:=0;

   BEGIN
   SELECT COUNT(*) INTO lv_invoice_hold FROM xxcd_bz_ap_invoice_holds_tb WHERE 1=1  AND status='SUCCESS' AND action='PUT_HOLD';
   EXCEPTION WHEN OTHERS THEN
   lv_invoice_hold:=0;
   END;
   -----------------------------------------------------------
    lv_invoice_release:=0;

   BEGIN
   SELECT COUNT(*) INTO lv_invoice_release FROM xxcd_bz_ap_invoice_holds_tb WHERE 1=1  AND status='SUCCESS' AND action='RELEASE_HOLD';
   EXCEPTION WHEN OTHERS THEN
   lv_invoice_release:=0;
   END;
   --------------------------------------------------------------

   fnd_file.put_line(fnd_file.output,'
   <Row>
    <Cell ss:Index="5"><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_invoice_hold||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_invoice_release||'</Data></Cell>
   </Row>');*/

   fnd_file.put_line(fnd_file.output,'
    </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Selected/>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>8</ActiveRow>
     <ActiveCol>5</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');

 fnd_file.put_line(fnd_file.output,'</Workbook>');
 EXCEPTION WHEN OTHERS THEN
 apps.fnd_file.put_line(apps.fnd_file.LOG,'Error Occured While executing the BAZ - Oracle EBS AP Invoice Hold and Release Details Report');
 apps.fnd_file.put_line(apps.fnd_file.LOG,'Error Code  :'||SQLCODE);
 apps.fnd_file.put_line(apps.fnd_file.LOG,'Error Message:'||SQLERRM);
 END XXCD_BZ_AP_INV_HOLDS_REL_PROC;