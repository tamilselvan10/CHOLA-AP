create or replace PROCEDURE xxcd_bz_ap_inv_int_result_proc(errbuf OUT VARCHAR2,retcode OUT VARCHAR2,p_from_date IN VARCHAR2,p_to_date IN VARCHAR2)
AS

lv_total   NUMBER:=0;
lv_success NUMBER:=0;
lv_failure NUMBER:=0;

BEGIN

fnd_file.put_line(fnd_file.output,'
<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
  <Author>Tamilselvan.E</Author>
  <LastAuthor>Tamilselvan.E</LastAuthor>
  <Created>2022-10-10T10:59:12Z</Created>
  <LastSaved>2022-10-10T11:10:02Z</LastSaved>
  <Version>16.00</Version>
 </DocumentProperties>
 <OfficeDocumentSettings xmlns="urn:schemas-microsoft-com:office:office">
  <AllowPNG/>
 </OfficeDocumentSettings>
 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
  <SupBook>
   <Library>EUROTOOL.XLAM</Library>
   <SheetName>1028</SheetName>
   <SheetName>1030</SheetName>
   <SheetName>1031</SheetName>
   <SheetName>1032</SheetName>
   <SheetName>1033</SheetName>
   <SheetName>1035</SheetName>
   <SheetName>1036</SheetName>
   <SheetName>1040</SheetName>
   <SheetName>1041</SheetName>
   <SheetName>1042</SheetName>
   <SheetName>1043</SheetName>
   <SheetName>1051</SheetName>
   <SheetName>1053</SheetName>
   <SheetName>1055</SheetName>
   <SheetName>1060</SheetName>
   <SheetName>1061</SheetName>
   <SheetName>1069</SheetName>
   <SheetName>1082</SheetName>
   <SheetName>2052</SheetName>
   <SheetName>2070</SheetName>
   <SheetName>3082</SheetName>
   <Xct>
    <Count>0</Count>
    <SheetIndex>0</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>1</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>2</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>3</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>4</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>5</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>6</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>7</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>8</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>9</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>10</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>11</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>12</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>13</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>14</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>15</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>16</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>17</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>18</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>19</SheetIndex>
   </Xct>
   <Xct>
    <Count>0</Count>
    <SheetIndex>20</SheetIndex>
   </Xct>
  </SupBook>
  <WindowHeight>7050</WindowHeight>
  <WindowWidth>20490</WindowWidth>
  <WindowTopX>0</WindowTopX>
  <WindowTopY>0</WindowTopY>
  <ProtectStructure>False</ProtectStructure>
  <ProtectWindows>False</ProtectWindows>
 </ExcelWorkbook>
 <Styles>
  <Style ss:ID="Default" ss:Name="Normal">
   <Alignment ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>
   <Interior/>
   <NumberFormat/>
   <Protection/>
  </Style>
  <Style ss:ID="s67">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="16" ss:Color="#000000"
    ss:Bold="1"/>
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s74">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Interior ss:Color="#B4C6E7" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s75">
   <Alignment ss:Horizontal="Right" ss:Vertical="Bottom"/>
   <Font ss:FontName="Dialog" ss:Size="11"/>
  </Style>
  <Style ss:ID="s79">
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s81">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"
    ss:Bold="1"/>
  </Style>
  <Style ss:ID="s82">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"
    ss:Bold="1"/>
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s86">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Interior ss:Color="#8EA9DB" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s91">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"
    ss:Bold="1"/>
  </Style>
  <Style ss:ID="s92">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s97">
   <Interior ss:Color="#B4C6E7" ss:Pattern="Solid"/>
  </Style>
 </Styles>
 <Worksheet ss:Name="Details">
  <Table ss:ExpandedColumnCount="100" ss:ExpandedRowCount="100" x:FullColumns="1"
   x:FullRows="1" ss:DefaultRowHeight="15">
   <Column ss:Index="6" ss:AutoFitWidth="0" ss:Width="81.75"/>
   <Row ss:Index="5" ss:Height="21">
    <Cell ss:Index="4" ss:MergeAcross="7" ss:StyleID="s67"><Data ss:Type="String">BAZ - Oracle EBS AP Invoice Integration</Data></Cell>
   </Row>
   <Row ss:Index="8">
    <Cell ss:Index="5" ss:StyleID="s74"><Data ss:Type="String">Sno</Data></Cell>
    <Cell ss:StyleID="s74"><Data ss:Type="String">Invoice Types</Data></Cell>
   </Row>
   <Row>
    <Cell ss:Index="5"><Data ss:Type="Number">1</Data></Cell>
    <Cell><Data ss:Type="String">Standard</Data></Cell>
   </Row>
   <Row>
    <Cell ss:Index="5"><Data ss:Type="Number">2</Data></Cell>
    <Cell><Data ss:Type="String">Debit Memo</Data></Cell>
   </Row>
   <Row>
    <Cell ss:Index="5"><Data ss:Type="Number">3</Data></Cell>
    <Cell><Data ss:Type="String">Credit Memo</Data></Cell>
   </Row>
   <Row>
    <Cell ss:Index="5"><Data ss:Type="Number">4</Data></Cell>
    <Cell><Data ss:Type="String">Prepayment</Data></Cell>
   </Row>
      <Row>
    <Cell ss:Index="5"><Data ss:Type="Number">5</Data></Cell>
    <Cell><Data ss:Type="String">Invoice With Prepayment</Data></Cell>
   </Row>
      <Row>
    <Cell ss:Index="5"><Data ss:Type="Number">6</Data></Cell>
    <Cell><Data ss:Type="String">CM Apply Against Invoice</Data></Cell>
   </Row>
   <Row>
    <Cell ss:Index="5"><Data ss:Type="Number">7</Data></Cell>
    <Cell><Data ss:Type="String">Invoice Hold and Release</Data></Cell>
   </Row>
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Selected/>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>10</ActiveRow>
     <ActiveCol>8</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
 ---------------------Sheet 1------------------------------------------------------------
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Invoice Header">
  <Table ss:ExpandedColumnCount="100" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="117.75" ss:DefaultRowHeight="15">
   <Column ss:Index="2" ss:AutoFitWidth="0" ss:Width="329.25"/>
   <Row ss:Index="3">
    <Cell ss:StyleID="s82"><Data ss:Type="String">Purpose </Data></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s81"><Data ss:Type="String"> AP Invoice Header</Data></Cell>
   </Row>
   <Row ss:Index="5">
    <Cell ss:StyleID="s86"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Operating Unit</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Batch Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Oracle Invoice ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">BAZ Invoice ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Site ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Site Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Number</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Description</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Source</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Currency</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Type</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Amount</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute Category</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute1</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute2</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute3</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute4</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute5</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute6</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute7</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute8</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute9</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute10</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute11</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute12</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute13</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute14</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE_CATEGORY</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE1</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE2</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE3</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE4</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE5</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE6</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE7</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE8</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE9</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE10</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE11</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE12</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE13</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE14</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE15</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE16</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE17</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE18</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE19</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE20</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GL Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Payment Terms</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Payment Method</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Prepay Flag</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Prepay Invoice No</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Prepay Line No</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Prepay Dist No</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Prepay Apply Amount</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">CM Apply Inv Flag</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">CM Apply Inv No</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">CM Apply Inv Status</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">CM Apply Inv Message</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Check ID</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Check Number</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Last Update Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">BAZ Process ID</Data></Cell>
   </Row>');

   FOR i IN (SELECT a.* FROM xxcd_bz_ap_invoice_headers_tb a WHERE 1=1 AND TRUNC(a.creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') ORDER by a.creation_date DESC)
   LOOP
   fnd_file.put_line(fnd_file.output,'
   <Row>
    <Cell><Data ss:Type="String">'||i.record_id||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.data_source||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.operating_unit||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.batch_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.oracle_invoice_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.baz_invoice_id||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.vendor_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_site_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_site_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.invoice_number||'</Data></Cell>	
    <Cell><Data ss:Type="String">'||i.invoice_description||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.invoice_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.source||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.invoice_currency_code||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.invoice_type||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.invoice_amount||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute_category||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute1||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute2||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute3||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute4||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute5||'</Data></Cell>

	<Cell><Data ss:Type="String">'||i.attribute6||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute7||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute8||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute9||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute10||'</Data></Cell>

	<Cell><Data ss:Type="String">'||i.attribute11||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute12||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute13||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute14||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE20||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.gl_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.terms_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.payment_method||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.prepay_flag||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.prepay_invoice_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.prepay_line_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.prepay_dist_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.prepay_apply_amount||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.cm_apply_inv_flag||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.cm_apply_inv_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.cm_apply_inv_status||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.cm_apply_inv_message||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.check_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.check_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.creation_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.last_update_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.status||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.error_message||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.baz_process_id||'</Data></Cell>
   </Row>');
   END LOOP;
   fnd_file.put_line(fnd_file.output,'
 </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <LeftColumnVisible>41</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>6</ActiveRow>
     <ActiveCol>1</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');

 -----Sheet2-----
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Invoice Lines">
  <Table ss:ExpandedColumnCount="100" ss:ExpandedRowCount="10000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="105" ss:DefaultRowHeight="15">
   <Column ss:Index="2" ss:AutoFitWidth="0" ss:Width="312.75"/>
   <Column ss:Index="7" ss:AutoFitWidth="0" ss:Width="210.75"/>
   <Column ss:Index="13" ss:AutoFitWidth="0" ss:Width="225"/>
   <Column ss:AutoFitWidth="0" ss:Width="231.75"/>
   <Column ss:AutoFitWidth="0" ss:Width="124.5"/>
   <Column ss:AutoFitWidth="0" ss:Width="126.75"/>
   <Column ss:AutoFitWidth="0" ss:Width="143.25"/>
   <Row ss:Index="3">
    <Cell ss:StyleID="s79"><Data ss:Type="String">Purpose </Data></Cell>
    <Cell ss:StyleID="s91"><Data ss:Type="String">AP Invoice lines</Data></Cell>
   </Row>
   <Row ss:Index="5">
    <Cell ss:StyleID="s86"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Operating Unit</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Batch Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Oracle Invoice ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">BAZ Invoice ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Site ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Site Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Number</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Line Number</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Line Description</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Line Amount</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Distribution Code Combination ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Distribution Code Combination</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Deferred Start date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Deferred End date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute category</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute1</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute2</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute3</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute4</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute5</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute6</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute7</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute8</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute9</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute10</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute11</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute12</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute13</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute14</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE_CATEGORY</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE1</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE2</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE3</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE4</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE5</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE6</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE7</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE8</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE9</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE10</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE11</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE12</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE13</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE14</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE15</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE16</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE17</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE18</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE19</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE20</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Last Update Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Error Message </Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">BAZ Process ID</Data></Cell>
   </Row>');

   FOR i IN (SELECT a.* FROM xxcd_bz_ap_invoice_lines_tb a WHERE 1=1 AND TRUNC(a.creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss')
						 ORDER BY a.creation_date DESC)
   LOOP
   fnd_file.put_line(fnd_file.output,'
   <Row>
    <Cell><Data ss:Type="String">'||i.record_id||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.data_source||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.operating_unit||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.batch_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.oracle_invoice_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.baz_invoice_id||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.vendor_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_site_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_site_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.invoice_number||'</Data></Cell>	
	<Cell><Data ss:Type="String">'||i.line_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.line_description||'</Data></Cell>
	<Cell><Data ss:Type="Number">'||i.line_amount||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.dist_code_combination_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.distribution_code_combination||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.DEFERRED_ACCT_START_DATE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.DEFERRED_ACCT_END_DATE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute_category||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute1||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute2||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute3||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute4||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute5||'</Data></Cell>	
	<Cell><Data ss:Type="String">'||i.attribute6||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute7||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute8||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute9||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute10||'</Data></Cell>	
	<Cell><Data ss:Type="String">'||i.attribute11||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute12||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute13||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute14||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute15||'</Data></Cell>	
	<Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE20||'</Data></Cell>	
	<Cell><Data ss:Type="String">'||i.creation_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.last_update_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.status||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.error_message||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.baz_process_id||'</Data></Cell>	
   </Row>');
   END LOOP;
   fnd_file.put_line(fnd_file.output,'
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>9</ActiveRow>
     <ActiveCol>1</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');

/******************************************************************************************************************/

 ---------------------Sheet 1------------------------------------------------------------
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Logging Invoice Header">
  <Table ss:ExpandedColumnCount="100" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="117.75" ss:DefaultRowHeight="15">
   <Column ss:Index="2" ss:AutoFitWidth="0" ss:Width="329.25"/>
   <Row ss:Index="3">
    <Cell ss:StyleID="s82"><Data ss:Type="String">Purpose </Data></Cell>
    <Cell ss:MergeAcross="2" ss:StyleID="s81"><Data ss:Type="String"> AP Invoice Header</Data></Cell>
   </Row>
   <Row ss:Index="5">
    <Cell ss:StyleID="s86"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Operating Unit</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Batch Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Oracle Invoice ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">BAZ Invoice ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Site ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Site Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Number</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Description</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Source</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Currency</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Type</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Amount</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute Category</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute1</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute2</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute3</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute4</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute5</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute6</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute7</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute8</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute9</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute10</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute11</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute12</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute13</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute14</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE_CATEGORY</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE1</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE2</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE3</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE4</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE5</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE6</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE7</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE8</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE9</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE10</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE11</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE12</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE13</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE14</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE15</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE16</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE17</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE18</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE19</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE20</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GL Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Payment Terms</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Payment Method</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Prepay Flag</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Prepay Invoice No</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Prepay Line No</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Prepay Dist No</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Prepay Apply Amount</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">CM Apply Inv Flag</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">CM Apply Inv No</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">CM Apply Inv Status</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">CM Apply Inv Message</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Check ID</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Check Number</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Last Update Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">BAZ Process ID</Data></Cell>
   </Row>');

   FOR i IN (SELECT a.* FROM xxcd_bz_ap_invoice_hdr_log_tb a WHERE 1=1 AND TRUNC(a.creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') ORDER by a.creation_date DESC)
   LOOP
   fnd_file.put_line(fnd_file.output,'
   <Row>
    <Cell><Data ss:Type="String">'||i.data_source||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.operating_unit||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.batch_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.oracle_invoice_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.baz_invoice_id||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.vendor_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_site_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_site_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.invoice_number||'</Data></Cell>	
    <Cell><Data ss:Type="String">'||i.invoice_description||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.invoice_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.source||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.invoice_currency_code||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.invoice_type||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.invoice_amount||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute_category||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute1||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute2||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute3||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute4||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute5||'</Data></Cell>

	<Cell><Data ss:Type="String">'||i.attribute6||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute7||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute8||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute9||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute10||'</Data></Cell>

	<Cell><Data ss:Type="String">'||i.attribute11||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute12||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute13||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute14||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE20||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.gl_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.terms_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.payment_method||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.prepay_flag||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.prepay_invoice_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.prepay_line_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.prepay_dist_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.prepay_apply_amount||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.cm_apply_inv_flag||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.cm_apply_inv_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.cm_apply_inv_status||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.cm_apply_inv_message||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.check_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.check_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.creation_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.last_update_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.status||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.error_message||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.baz_process_id||'</Data></Cell>
   </Row>');
   END LOOP;
   fnd_file.put_line(fnd_file.output,'
 </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <LeftColumnVisible>41</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>6</ActiveRow>
     <ActiveCol>1</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');

 -----Sheet2-----
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Logging Invoice Lines">
  <Table ss:ExpandedColumnCount="100" ss:ExpandedRowCount="10000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="105" ss:DefaultRowHeight="15">
   <Column ss:Index="2" ss:AutoFitWidth="0" ss:Width="312.75"/>
   <Column ss:Index="7" ss:AutoFitWidth="0" ss:Width="210.75"/>
   <Column ss:Index="13" ss:AutoFitWidth="0" ss:Width="225"/>
   <Column ss:AutoFitWidth="0" ss:Width="231.75"/>
   <Column ss:AutoFitWidth="0" ss:Width="124.5"/>
   <Column ss:AutoFitWidth="0" ss:Width="126.75"/>
   <Column ss:AutoFitWidth="0" ss:Width="143.25"/>
   <Row ss:Index="3">
    <Cell ss:StyleID="s79"><Data ss:Type="String">Purpose </Data></Cell>
    <Cell ss:StyleID="s91"><Data ss:Type="String">AP Invoice lines</Data></Cell>
   </Row>
   <Row ss:Index="5">
    <Cell ss:StyleID="s86"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Operating Unit</Data></Cell>
	<Cell ss:StyleID="s86"><Data ss:Type="String">Batch Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Oracle Invoice ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">BAZ Invoice ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Site ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Vendor Site Name</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Invoice Number</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Line Number</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Line Description</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Line Amount</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Distribution Code Combination ID</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Distribution Code Combination</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Deferred Start date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Deferred End date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute category</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute1</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute2</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute3</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute4</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute5</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute6</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute7</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute8</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute9</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute10</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute11</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute12</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute13</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute14</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE_CATEGORY</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE1</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE2</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE3</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE4</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE5</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE6</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE7</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE8</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE9</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE10</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE11</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE12</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE13</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE14</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE15</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE16</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE17</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE18</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE19</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">GLOBAL_ATTRIBUTE20</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Last Update Date</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">Error Message </Data></Cell>
    <Cell ss:StyleID="s86"><Data ss:Type="String">BAZ Process ID</Data></Cell>
   </Row>');

   FOR i IN (SELECT a.* FROM xxcd_bz_ap_invoice_lns_log_tb a WHERE 1=1 AND TRUNC(a.creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss')
						 ORDER BY a.creation_date DESC)
   LOOP
   fnd_file.put_line(fnd_file.output,'
   <Row>
    <Cell><Data ss:Type="String">'||i.data_source||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.operating_unit||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.batch_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.oracle_invoice_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.baz_invoice_id||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.vendor_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_site_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.vendor_site_name||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.invoice_number||'</Data></Cell>	
	<Cell><Data ss:Type="String">'||i.line_number||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.line_description||'</Data></Cell>
	<Cell><Data ss:Type="Number">'||i.line_amount||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.dist_code_combination_id||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.distribution_code_combination||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.DEFERRED_ACCT_START_DATE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.DEFERRED_ACCT_END_DATE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute_category||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute1||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute2||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute3||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute4||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute5||'</Data></Cell>	
	<Cell><Data ss:Type="String">'||i.attribute6||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute7||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute8||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute9||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute10||'</Data></Cell>	
	<Cell><Data ss:Type="String">'||i.attribute11||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute12||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute13||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute14||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.attribute15||'</Data></Cell>	
	<Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE20||'</Data></Cell>	
	<Cell><Data ss:Type="String">'||i.creation_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.last_update_date||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.status||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.error_message||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.baz_process_id||'</Data></Cell>	
   </Row>');
   END LOOP;
   fnd_file.put_line(fnd_file.output,'
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>9</ActiveRow>
     <ActiveCol>1</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
/******************************************************************************************************************/

 --- Summary:
 fnd_file.put_line(fnd_file.output,'
<Worksheet ss:Name="Summary">
  <Table ss:ExpandedColumnCount="100" ss:ExpandedRowCount="100" x:FullColumns="1"
   x:FullRows="1" ss:DefaultRowHeight="15">
   <Column ss:Index="2" ss:AutoFitWidth="0" ss:Width="71.25"/>
   <Column ss:AutoFitWidth="0" ss:Width="121.5"/>
   <Column ss:AutoFitWidth="0" ss:Width="182.25"/>
   <Column ss:AutoFitWidth="0" ss:Width="103.5"/>
   <Column ss:AutoFitWidth="0" ss:Width="106.5"/>
   <Row ss:Index="4">
    <Cell ss:Index="3" ss:MergeAcross="2" ss:StyleID="s92"><Data ss:Type="String">BAZ - Oracle EBS AP Invoice Integration Process Summary</Data></Cell>
   </Row>
   <Row ss:Index="6">
    <Cell ss:Index="3" ss:StyleID="s97"><Data ss:Type="String">Total.No.of.Records</Data></Cell>
    <Cell ss:StyleID="s97"><Data ss:Type="String">Total Success Records</Data></Cell>
    <Cell ss:StyleID="s97"><Data ss:Type="String">Total Failure Records</Data></Cell>
   </Row>');

   lv_total:=0;

   BEGIN
   SELECT COUNT(*) INTO lv_total FROM xxcd_bz_ap_invoice_headers_tb WHERE 1=1 AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss');
   EXCEPTION WHEN OTHERS THEN
   lv_total:=0;
   END;
   -----------------------------------------------------------
   lv_success:=0;

   BEGIN
   SELECT COUNT(*) INTO lv_success FROM xxcd_bz_ap_invoice_headers_tb WHERE 1=1 AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND STATUS='SUCCESS';
   EXCEPTION WHEN OTHERS THEN
   lv_success:=0;
   END;
   -----------------------------------------------------------
   lv_failure:=0;

   BEGIN
   SELECT COUNT(*) INTO lv_failure FROM xxcd_bz_ap_invoice_headers_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                         AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND STATUS<>'SUCCESS';
   EXCEPTION WHEN OTHERS THEN
   lv_failure:=0;
   END;
   --------------------------------------------------------------
    fnd_file.put_line(fnd_file.output,'
   <Row>
    <Cell ss:Index="3"><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_success||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_failure||'</Data></Cell>
   </Row>
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>10</ActiveRow>
     <ActiveCol>4</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>
</Workbook>
');

END xxcd_bz_ap_inv_int_result_proc;