URL:  http://preprodr12app.chola.murugappa.com:8011/webservices/rest/ap_inv_cancel/cancel_ap_invoice/

Method:POST

Basic Authentication:
----------------------
username:ASADMIN
pwd:Welcome@123

Request Body:
----------------

{
  "CANCEL_AP_INVOICE_Input": {
    "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/ap_inv_cancel/cancel_ap_invoice/",
    "RESTHeader": {
      "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
    },
    "InputParameters": {
      "DATA_SOURCE": "BAZ",
      "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
      "INVOICE_NUMBER": "inv-5122022",
      "VENDOR_ID": 5193051,
      "VENDOR_SITE_ID": 153115,
      "VENDOR_NAME": "AAKFA1408J ARUN AGRICULTURE",
      "VENDOR_SITE_NAME": "RAIPUR"
    }
  }
}

Response Body:
--------------

{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/ap_inv_cancel/cancel_ap_invoice/",
        "TIMESTAMP": "14-DEC-2022 09:30:29",
        "RETURN_STATUS": "S",
        "RETURN_MESSAGE": "Invoice Number: inv-5122022 Cancelled."
    }
}