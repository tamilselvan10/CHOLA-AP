URL: http://preprodr12app.chola.murugappa.com:8011/webservices/rest/ap_inv_data_rev_feed/getinvoicedata/

Method: POST
Basic Authentication:
----------------------
Username/password: ASADMIN/Welcome@123


Request Body:
-------------
{
  "GETINVOICEDATA_Input": {
    "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/ap_inv_data_rev_feed/getinvoicedata/",
    "RESTHeader": {
      "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
    },
    "InputParameters": {
      "DATA_SOURCE": "BAZ",
      "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
      "INVOICE_NUMBER": "20221216_INV_5",
      "VENDOR_ID": 6669801,
      "VENDOR_SITE_ID": 415342,
      "VENDOR_NAME": "APEPDCL-GUDIWADA",
      "VENDOR_SITE_NAME": "GUDIWADA"
    }
  }
}

Response Body:
--------------

{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/ap_inv_data_rev_feed/getinvoicedata/",
        "GETINVOICEDATA": "20221216_INV_5",
        "TIMESTAMP": "23-DEC-2022 17:55:01",
        "RETURN_STATUS": "SUCESS",
        "RETURN_MESSAGE": "SUCCESS"
    }
}