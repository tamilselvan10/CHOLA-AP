URL:  http://preprodr12app.chola.murugappa.com:8011/webservices/rest/gst_release/ap_inv_gst_release/

Method: POST
Basic Authentication:
----------------------
Username/password: ASADMIN/welcome@123


Request Body:
-------------
{
  "AP_INVOICE_HOLD_RELEASE_Input": {
    "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/gst_release/ap_inv_gst_release/",
    "RESTHeader": {
      "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
    },
    "InputParameters": {
      "DATA_SOURCE": "BAZ",
      "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
      "INVOICE_NUMBER": "HOLD_TEST_23",
      "VENDOR_ID": 6669801,
      "VENDOR_SITE_ID": 415342,
      "VENDOR_NAME": "APEPDCL-GUDIWADA",
      "VENDOR_SITE_NAME": "GUDIWADA"
    }
  }
}

Response Body:
-----------------

{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/gst_release/ap_inv_gst_release/",
        "TIMESTAMP": "03-JAN-2023 18:15:28",
        "RETURN_STATUS": "E",
        "RETURN_MESSAGE": "Already In Hold"
    }
}