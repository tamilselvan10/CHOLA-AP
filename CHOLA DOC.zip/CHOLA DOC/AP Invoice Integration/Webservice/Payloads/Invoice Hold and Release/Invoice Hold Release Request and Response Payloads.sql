URL: http://preprodr12app.chola.murugappa.com:8011/webservices/rest/ap_inv_hold_release/ap_invoice_hold_release/

Method: POST
Basic Authentication:
---------------------
Username/password: ASADMIN/Welcome@123



Case1: Invoice Hold
--------------------

Request Payload:
----------------

{
  "AP_INVOICE_HOLD_RELEASE_Input": {
    "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/ap_inv_hold_release/ap_invoice_hold_release/",
    "RESTHeader": {
      "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
    },
    "InputParameters": {
      "DATA_SOURCE": "BAZ",
      "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
      "INVOICE_NUMBER": "20OCT20221INT_01",
      "VENDOR_ID": 6668398,
      "VENDOR_SITE_ID": 413800,
      "VENDOR_NAME": "TEST_SUPPLIER70",
      "VENDOR_SITE_NAME": "TEST_SUP70_SI",
      "ACTION": "PUT_HOLD",
      "HOLD_CODE": "VENDOR",
      "HOLD_TYPE": "INVOICE HOLD REASON",
      "HOLD_REASON": "Hold all unvalidated invoices for supplier",
      "RELEASE_CODE": null,
      "RELEASE_REASON": null
    }
  }
}

Response Payload:
------------------
{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/ap_inv_hold_release/ap_invoice_hold_release/",
        "TIMESTAMP": "20-OCT-2022 23:19:23",
        "RETURN_STATUS": "S",
        "RETURN_MESSAGE": "Invoice Number: 20OCT20221INT_01 created a hold"
    }
}

Case2: Invoice Release
----------------------

Request Payload:
----------------

{
  "AP_INVOICE_HOLD_RELEASE_Input": {
    "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/ap_inv_hold_release/ap_invoice_hold_release/",
    "RESTHeader": {
      "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
    },
    "InputParameters": {
      "DATA_SOURCE": "BAZ",
      "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
      "INVOICE_NUMBER": "20OCT20221INT_01",
      "VENDOR_ID": 6668398,
      "VENDOR_SITE_ID": 413800,
      "VENDOR_NAME": "TEST_SUPPLIER70",
      "VENDOR_SITE_NAME": "TEST_SUP70_SI",
      "ACTION": "RELEASE_HOLD",
      "HOLD_CODE": null,
      "HOLD_TYPE": null,
      "HOLD_REASON": null,
      "RELEASE_CODE": "HOLDS QUICK RELEASED",
      "RELEASE_REASON": "Holds manually released"
    }
  }
}

Response Payload:
-----------------
{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/ap_inv_hold_release/ap_invoice_hold_release/",
        "TIMESTAMP": "20-OCT-2022 23:25:15",
        "RETURN_STATUS": "S",
        "RETURN_MESSAGE": "Invoice Number :20OCT20221INT_01 released a hold"
    }
}