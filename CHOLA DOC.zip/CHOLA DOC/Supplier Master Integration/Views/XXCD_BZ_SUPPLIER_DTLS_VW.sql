 CREATE OR REPLACE VIEW "XXCD_BZ_SUPPLIER_DTLS_VW" 
 AS
  SELECT UNIQUE
     aps.segment1                vendor_number,
	 aps.vendor_name             vendor_name,
	 assa.vendor_site_code       vendor_site_name,
--	jprv.party_site_address      vendor_site_address,
    assa.ADDRESS_LINE1||' '||assa.ADDRESS_LINE2||' '||assa.ADDRESS_LINE3||' '||assa.CITY||' '||assa.STATE||' '||assa.ZIP||' '||assa.COUNTRY vendor_site_address,
     cbbv.bank_name              bank_name,
     cbbv.bank_branch_name       bank_branch_name,
     ieb.attribute3        ifsc_code,
	 ieb.bank_account_num        bank_account_name,
     ieb.bank_account_num        bank_account_number,
	 CASE WHEN jprlv.registration_type_code = 'PAN' THEN registration_number
	      WHEN jprlv.sec_registration_type_code = 'PAN' THEN secondary_registration_number
		  ELSE NULL
		  END AS pan_number,
     CASE WHEN jprlv.registration_type_code LIKE '%GST%' THEN registration_number
	      WHEN jprlv.sec_registration_type_code LIKE '%GST%' THEN secondary_registration_number
		  ELSE NULL
		  END AS gst_number

FROM apps.ap_suppliers            aps,
     apps.ap_supplier_sites_all   assa,
	 apps.iby_external_payees_all payees,
	 apps.iby_account_owners      owners,
	 apps.iby_pmt_instr_uses_all  instrument,
	 apps.iby_ext_bank_accounts   ieb,
	 apps.ce_bank_branches_v      cbbv,
	 apps.jai_party_regs_v        jprv,
	 apps.jai_party_reg_lines_v   jprlv
	 
WHERE 1=1
AND aps.vendor_id              = assa.vendor_id
AND assa.vendor_site_id        = payees.supplier_site_id
AND payees.payee_party_id      = owners.account_owner_party_id
AND owners.primary_flag        = 'Y'
AND owners.ext_bank_account_id = instrument.instrument_id
AND payees.ext_payee_id        = instrument.ext_pmt_party_id
AND owners.ext_bank_account_id = ieb.ext_bank_account_id
AND ieb.branch_id              = cbbv.branch_party_id(+)
AND aps.vendor_id              = jprv.party_id
AND assa.vendor_site_id        = jprv.party_site_id
AND assa.org_id                = jprv.org_id
AND jprv.party_reg_id          = jprlv.party_reg_id
AND jprv.site_flag             = 'Y'
AND jprv.supplier_flag         = 'Y'
AND jprlv.effective_to IS NULL;