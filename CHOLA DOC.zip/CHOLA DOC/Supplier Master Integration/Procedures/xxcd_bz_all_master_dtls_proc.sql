create or replace PROCEDURE xxcd_bz_all_master_dtls_proc(errbuf OUT VARCHAR2,retcode OUT VARCHAR2,p_from_date IN VARCHAR2,p_to_date IN VARCHAR2)
AS
											
lv_total   NUMBER:=0;
lv_success NUMBER:=0;
lv_failure NUMBER:=0;
lv_error_message  VARCHAR2(4000):=NULL;

BEGIN


fnd_file.put_line(fnd_file.output,'<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
  <Author>Tamilselvan.E</Author>
  <LastAuthor>Tamilselvan.E</LastAuthor>
  <Created>2022-11-15T13:19:21Z</Created>
  <LastSaved>2022-11-16T05:22:44Z</LastSaved>
  <Version>16.00</Version>
 </DocumentProperties>
 <OfficeDocumentSettings xmlns="urn:schemas-microsoft-com:office:office">
  <AllowPNG/>
 </OfficeDocumentSettings>
 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
  <WindowHeight>7050</WindowHeight>
  <WindowWidth>20490</WindowWidth>
  <WindowTopX>0</WindowTopX>
  <WindowTopY>0</WindowTopY>
  <ActiveSheet>14</ActiveSheet>
  <FirstVisibleSheet>11</FirstVisibleSheet>
  <ProtectStructure>False</ProtectStructure>
  <ProtectWindows>False</ProtectWindows>
 </ExcelWorkbook>
 <Styles>
  <Style ss:ID="Default" ss:Name="Normal">
   <Alignment ss:Vertical="Bottom"/>
   <Borders/>
   <Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>
   <Interior/>
   <NumberFormat/>
   <Protection/>
  </Style>
  <Style ss:ID="s62">
   <Font ss:FontName="Verdana" x:Family="Swiss" ss:Size="20" ss:Color="#000000"
    ss:Bold="1"/>
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s63">
   <Interior ss:Color="#8EA9DB" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s64">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
  </Style>
  <Style ss:ID="s65">
   <Alignment ss:Horizontal="Center" ss:Vertical="Bottom"/>
   <Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>
  </Style>
  <Style ss:ID="s66">
   <Interior ss:Color="#B4C6E7" ss:Pattern="Solid"/>
  </Style>
 </Styles>
 <Worksheet ss:Name="Report">
  <Table ss:ExpandedColumnCount="12" ss:ExpandedRowCount="7" x:FullColumns="1"
   x:FullRows="1" ss:DefaultRowHeight="15">
   <Column ss:Index="12" ss:AutoFitWidth="0" ss:Width="238.5"/>
   <Row ss:AutoFitHeight="0"/>
   <Row ss:Index="7" ss:AutoFitHeight="0" ss:Height="26.25">
    <Cell ss:Index="6" ss:StyleID="s62"><Data ss:Type="String">Supplier Master Integration Summary Report</Data></Cell>
    <Cell ss:StyleID="s62"/>
    <Cell ss:StyleID="s62"/>
    <Cell ss:StyleID="s62"/>
    <Cell ss:StyleID="s62"/>
    <Cell ss:StyleID="s62"/>
    <Cell ss:StyleID="s62"/>
   </Row>
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>14</ActiveRow>
     <ActiveCol>7</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
 
  --- Sheet1.0: Creation Main:
 fnd_file.put_line(fnd_file.output,'<Worksheet ss:Name="Creation Main">
  <Table ss:ExpandedColumnCount="251" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="145.5" ss:DefaultRowHeight="15">
   <Row ss:AutoFitHeight="0"/>
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s63"><Data ss:Type="String">Process</Data></Cell>
    <Cell><Data ss:Type="String">All Master(Supplier, Supplier Site,Bank,Bank Branch,Bank Account,GST and PAN),Existing Supplier New Site and Existing Supplier New (Bank,Branch and Bank Account)</Data></Cell>
   </Row>
   <Row ss:Index="4" ss:AutoFitHeight="0">
    <Cell ss:StyleID="s64"/>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Org ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Operating Unit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Alternate Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Enabled Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Type</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment terms</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">One Time Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Customer Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Parent Vendor ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Min Order Amount</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Sets of Books Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Pay group Lookup Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Payment priority</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Invoice Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Payment Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Invoice Amount Limit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Hold All Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Hold Future Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Reason</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Start Date Active</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor End Date Active</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">National Insurance Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">EDI payment Method</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">URL</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Remittance Email</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">CEO Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">CEO Title</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site Code Alt</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">City</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">State</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">ZIP</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Province</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Country</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Purchasing Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">RFQ Only Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Pay Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Primary Pay Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Invoice Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Payment Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Hold all Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Hold Future Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Hold Reason</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Phone Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Email Address</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">DUNS Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Payment priority</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Customer Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Area Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Fax</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Fax Area code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Liability Account</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Prepayment Account</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bills Payable Account</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Payment Terms</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Legal Business Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Invoice Amount Limit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Inactive Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Short Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Country Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute21</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute22</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute23</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute24</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute25</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Branch Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">EFT Swift Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">BIC</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute21</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute22</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute23</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute24</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute25</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Short Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">IBAN</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Check Digits</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Multi Currency Allowed Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Type</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Suffix</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Country Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">PAN Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">GST Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Last update date</Data></Cell>
   </Row>');
   
   
   FOR i IN (SELECT * FROM xxcd_bz_all_supmst_crt_main_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') ORDER BY creation_date DESC)
   LOOP
   
      lv_error_message:=NULL;
   --- Get Error Message:
   BEGIN
   SELECT  CASE WHEN error_message LIKE 'SQLAP%VENDOR%NUMBER%' THEN 'Vendor Number Is Incorrect' ELSE error_message END 
   INTO lv_error_message
   FROM xxcd_bz_all_supmst_crt_main_tb
   WHERE 1=1
   AND record_id=i.record_id;
   EXCEPTION WHEN OTHERS THEN
   lv_error_message:=NULL;
   END;
  
  
   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="String">'||i.DATA_SOURCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RECORD_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ORG_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.OPERATING_UNIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ALTERNATE_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ENABLED_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_TYPE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_PAYMENT_TERMS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ONE_TIME_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_CUSTOMER_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PARENT_VENDOR_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.MIN_ORDER_AMOUNT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SET_OF_BOOKS_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAY_GROUP_LOOKUP_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_PAYMENT_PRIORITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_INVOICE_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_PAYMENT_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INVOICE_AMOUNT_LIMIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_HOLD_ALL_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_HOLD_FUTURE_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_REASON||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_DATE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.VDR_START_DATE_ACTIVE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.VDR_END_DATE_ACTIVE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.NI_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EDI_PAYMENT_METHOD||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.URL||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.REMITTANCE_EMAIL||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CEO_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CEO_TITLE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_CODE_ALT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ZIP||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PROVINCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.COUNTRY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PURCHASING_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RFQ_ONLY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PRIMARY_PAY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_INVOICE_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_PAYMENT_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_HOLD_ALL_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_HOLD_FUTURE_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_HOLD_REASON||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PHONE_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EMAIL_ADDRESS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.DUNS_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_PAYMENT_PRIORITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_CUSTOMER_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.AREA_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.FAX||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.FAX_AREA_CODE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.LIABILITY_ACCOUNT||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.PREPAYMENT_ACCOUNT||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.BILLS_PAYABLE_ACCOUNT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_PAYMENT_TERMS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LEGAL_BUSINESS_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_INVOICE_AMOUNT_LIMIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INACTIVE_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SHORT_BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_COUNTRY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE21||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE22||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE23||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE24||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE25||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_BRANCH_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EFT_SWIFT_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BIC||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE21||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE22||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE23||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE24||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE25||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SHORT_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.IBAN||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CHECK_DIGITS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.MULTI_CURRENCY_ALLOWED_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_TYPE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_SUFFIX||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_COUNTRY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANKACCOUNT_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAN_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GST_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATUS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||lv_error_message||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CREATION_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LAST_UPDATE_DATE||'</Data></Cell>
   </Row>');
   END LOOP;
   
   fnd_file.put_line(fnd_file.output,'
   </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <LeftColumnVisible>245</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>4</ActiveRow>
     <ActiveCol>248</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
 

 --- Sheet1.1: Supplier All Master:
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="All Master">
  <Table ss:ExpandedColumnCount="248" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="145.5" ss:DefaultRowHeight="15">
   <Row ss:AutoFitHeight="0"/>
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s63"><Data ss:Type="String">Process</Data></Cell>
    <Cell><Data ss:Type="String">All Master(Supplier, Supplier Site,Bank,Bank Branch,Bank Account,GST and PAN)</Data></Cell>
   </Row>
   <Row ss:Index="4" ss:AutoFitHeight="0">
    <Cell ss:StyleID="s64"/>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Org ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Operating Unit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Alternate Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Enabled Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Type</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment terms</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">One Time Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Customer Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Parent Vendor ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Min Order Amount</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Sets of Books Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Pay group Lookup Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment priority</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Invoice Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Invoice Amount Limit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold All Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Future Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Reason</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">National Insurance Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">EDI payment Method</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">URL</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Remittance Email</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">CEO Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">CEO Title</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site Code Alt</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">City</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">State</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">ZIP</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Province</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Country</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Purchasing Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">REQ Only Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Pay Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Primary Pay Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Invoice Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Payment Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Hold all Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Hold Future Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Reason</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Phone Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Email Address</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">DUNS Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Payment priority</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Customer Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Area Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Fax</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Fax Area code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Payment Terms</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Legal Business Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Invoice Amount Limit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Inactive Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Short Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Country Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute21</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute22</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute23</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute24</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute25</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Branch Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">EFT Swift Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">BIC</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute21</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute22</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute23</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute24</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute25</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Short Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">IBAN</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Check Digits</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Multi Currency Allowed Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Type</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Suffix</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Start Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">End Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Country Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">PAN Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">GST Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Last update date</Data></Cell>
   </Row>');
   
   
 
   FOR i IN (SELECT * FROM xxcd_bz_sup_all_mst_crt_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') ORDER BY creation_date DESC)
   LOOP
   
      lv_error_message:=NULL;
   --- Get Error Message:
   BEGIN
   SELECT  CASE WHEN error_message LIKE 'SQLAP%VENDOR%NUMBER%' THEN 'Vendor Number Is Incorrect' ELSE error_message END 
   INTO lv_error_message
   FROM xxcd_bz_sup_all_mst_crt_tb
   WHERE 1=1
   AND record_id=i.record_id;
   EXCEPTION WHEN OTHERS THEN
   lv_error_message:=NULL;
   END;
  
  
   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="String">'||i.DATA_SOURCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RECORD_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ORG_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.OPERATING_UNIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ALTERNATE_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ENABLED_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_TYPE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_PAYMENT_TERMS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ONE_TIME_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_CUSTOMER_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PARENT_VENDOR_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.MIN_ORDER_AMOUNT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SET_OF_BOOKS_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAY_GROUP_LOOKUP_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_PAYMENT_PRIORITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_INVOICE_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_PAYMENT_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INVOICE_AMOUNT_LIMIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_HOLD_ALL_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_HOLD_FUTURE_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_REASON||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.NI_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EDI_PAYMENT_METHOD||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.URL||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.REMITTANCE_EMAIL||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CEO_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CEO_TITLE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_CODE_ALT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ZIP||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PROVINCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.COUNTRY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PURCHASING_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RFQ_ONLY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PRIMARY_PAY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_INVOICE_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_PAYMENT_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_HOLD_ALL_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_HOLD_FUTURE_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_HOLD_REASON||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PHONE_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EMAIL_ADDRESS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.DUNS_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_PAYMENT_PRIORITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_CUSTOMER_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.AREA_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.FAX||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.FAX_AREA_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_PAYMENT_TERMS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LEGAL_BUSINESS_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_INVOICE_AMOUNT_LIMIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INACTIVE_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SHORT_BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_COUNTRY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE21||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE22||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE23||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE24||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE25||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_BRANCH_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EFT_SWIFT_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BIC||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE21||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE22||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE23||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE24||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE25||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SHORT_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.IBAN||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CHECK_DIGITS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.MULTI_CURRENCY_ALLOWED_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_TYPE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_SUFFIX||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||NULL||'</Data></Cell>
    <Cell><Data ss:Type="String">'||NULL||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_COUNTRY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANKACCOUNT_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAN_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GST_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATUS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||lv_error_message||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CREATION_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LAST_UPDATE_DATE||'</Data></Cell>');

	fnd_file.put_line(fnd_file.output,'
   </Row>');
   END LOOP;
   
   fnd_file.put_line(fnd_file.output,'
     </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <LeftColumnVisible>242</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>4</ActiveRow>
     <ActiveCol>245</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
 
 
  --- Sheet1.2: Existing Supplier New Site creation:
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Existing Supplier New Site">
  <Table ss:ExpandedColumnCount="82" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="126" ss:DefaultRowHeight="15">
   <Row ss:AutoFitHeight="0"/>
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s63"><Data ss:Type="String">Process</Data></Cell>
    <Cell><Data ss:Type="String">Existing Supplier New site</Data></Cell>
   </Row>
   <Row ss:Index="4" ss:AutoFitHeight="0">
    <Cell ss:StyleID="s64"/>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Org ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Operating Unit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site code Alt</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">City</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">State</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">ZIP</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Province</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Country</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Purchasing Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">RFQ Only Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Pay Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Primary Pay Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Invoice Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold all payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Future Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold reason</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Phone Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Email Address</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">DUNS Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment priority</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Customer Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Area Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Fax </Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Fax Area code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment Terms</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Legal Business Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Invoice Amount Limit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Inactive date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Last Update Date</Data></Cell>
   </Row>');
   
   
   FOR i IN (SELECT * FROM xxcd_bz_sup_site_mst_crt_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss')
																  ORDER BY creation_date DESC)
   LOOP


   lv_error_message:=NULL;
   --- Get Error Message:
   BEGIN
   SELECT  CASE WHEN error_message LIKE 'SQLAP%VENDOR%NUMBER%' THEN 'Vendor Number Is Incorrect' ELSE error_message END 
   INTO lv_error_message
   FROM xxcd_bz_sup_site_mst_crt_tb
   WHERE 1=1
   AND record_id=i.record_id;
   EXCEPTION WHEN OTHERS THEN
   lv_error_message:=NULL;
   END;
  
  
  
   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="String">'||i.DATA_SOURCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RECORD_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ORG_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.OPERATING_UNIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_CODE_ALT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ZIP||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PROVINCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.COUNTRY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PURCHASING_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RFQ_ONLY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PRIMARY_PAY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INVOICE_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAYMENT_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_ALL_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_FUTURE_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_REASON||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PHONE_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EMAIL_ADDRESS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.DUNS_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAYMENT_PRIORITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CUSTOMER_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.AREA_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.FAX||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.FAX_AREA_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAYMENT_TERMS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LEGAL_BUSINESS_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INVOICE_AMOUNT_LIMIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INACTIVE_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATUS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||lv_error_message||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CREATION_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LAST_UPDATE_DATE||'</Data></Cell>
   </Row>');
   END LOOP;
   
   fnd_file.put_line(fnd_file.output,'
   </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <LeftColumnVisible>75</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>5</ActiveRow>
     <RangeSelection>R6</RangeSelection>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
 
  --- Sheet1.3: Existing Supplier New Bank, Branch and Bank Account Creation:
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Existing Supplier New Bank Dtls">
  <Table ss:ExpandedColumnCount="116" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="121.5" ss:DefaultRowHeight="15">
   <Row ss:AutoFitHeight="0"/>
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s66"><Data ss:Type="String">Process</Data></Cell>
    <Cell><Data ss:Type="String">Existing Supplier New Bank,Branch and Bank Account</Data></Cell>
   </Row>
   <Row ss:Index="4" ss:AutoFitHeight="0">
    <Cell ss:StyleID="s64"/>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Org ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Operating Unit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Short Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Country Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute21</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute22</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute23</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute24</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute25</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Branch Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">EFT Swift Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">BIC</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute21</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute22</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute23</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute24</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute25</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Short Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">IBAN</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Check Digits</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Multi Currency Allowed Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Type</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Suffix</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Start Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">End Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Country Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Last Update Date</Data></Cell>
   </Row>');
   
FOR i IN (SELECT * FROM xxcd_bz_bank_crt_dtls_tb WHERE 1=1 
    AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss')
																  ORDER BY creation_date DESC)
   LOOP
   
      lv_error_message:=NULL;
   --- Get Error Message:
   BEGIN
   SELECT  CASE WHEN error_message LIKE 'SQLAP%VENDOR%NUMBER%' THEN 'Vendor Number Is Incorrect' ELSE error_message END 
   INTO lv_error_message
   FROM xxcd_bz_bank_crt_dtls_tb
   WHERE 1=1
   AND record_id=i.record_id;
   EXCEPTION WHEN OTHERS THEN
   lv_error_message:=NULL;
   END;
  
  
  
   fnd_file.put_line(fnd_file.output,'   
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="String">'||i.DATA_SOURCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RECORD_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ORG_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.OPERATING_UNIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SHORT_BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_COUNTRY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE21||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE22||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE23||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE24||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE25||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_BRANCH_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EFT_SWIFT_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BIC||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE21||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE22||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE23||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE24||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE25||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SHORT_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.IBAN||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CHECK_DIGITS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.MULTI_CURRENCY_ALLOWED_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_TYPE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_SUFFIX||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.START_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.END_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_COUNTRY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANKACCOUNT_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATUS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||lv_error_message||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CREATION_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LAST_UPDATE_DATE||'</Data></Cell>
   </Row>');

   END LOOP;
   
   fnd_file.put_line(fnd_file.output,' 
   </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <LeftColumnVisible>108</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>4</ActiveRow>
     <ActiveCol>113</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
 
 
 
  
 /*===========================================================================================================================================================*/
  --- Sheet2.0: Updation Main:
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Updation Main">
  <Table ss:ExpandedColumnCount="255" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="145.5" ss:DefaultRowHeight="15">
   <Row ss:AutoFitHeight="0"/>
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s63"><Data ss:Type="String">Process</Data></Cell>
    <Cell><Data ss:Type="String">Update All Supplier Master</Data></Cell>
   </Row>
   <Row ss:Index="4" ss:AutoFitHeight="0">
    <Cell ss:StyleID="s64"/>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Org ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Operating Unit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Alternate Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Enabled Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Type</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment terms</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">One Time Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Customer Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Parent Vendor ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Min Order Amount</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Sets of Books Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Pay group Lookup Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Payment priority</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Invoice Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Payment Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Invoice Amount Limit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Hold All Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Hold Future Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Reason</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Start Date Active</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor End Date Active</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Global Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">National Insurance Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">EDI payment Method</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">URL</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Remittance Email</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">CEO Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">CEO Title</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site Code Alt</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">City</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">State</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">ZIP</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Province</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Country</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Purchasing Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">RFQ Only Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Pay Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Primary Pay Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Invoice Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Payment Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Hold all Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Hold Future Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Hold Reason</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Phone Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Email Address</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">DUNS Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Payment priority</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Customer Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Area Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Fax</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Fax Area code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Liability Account</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Prepayment Account</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bills Payable Account</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Global Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Payment Terms</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Legal Business Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Site Invoice Amount Limit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Inactive Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Short Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Country Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank End Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute21</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute22</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute23</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute24</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Attribute25</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Branch Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">EFT Swift Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">BIC</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch End Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute21</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute22</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute23</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute24</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Attribute25</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Short Account Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">IBAN</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Check Digits</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Multi Currency Allowed Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Type</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Suffix</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Country Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account Start Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Account End Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Account Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">PAN Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">GST Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Last update date</Data></Cell>
   </Row>');
   
    FOR i IN (SELECT * FROM xxcd_bz_all_supmst_upd_main_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss')
																  ORDER BY creation_date DESC)
   LOOP
   
      lv_error_message:=NULL;
   --- Get Error Message:
   BEGIN
   SELECT  CASE WHEN error_message LIKE 'SQLAP%VENDOR%NUMBER%' THEN 'Vendor Number Is Incorrect' ELSE error_message END 
   INTO lv_error_message
   FROM xxcd_bz_all_supmst_upd_main_tb
   WHERE 1=1
   AND record_id=i.record_id;
   EXCEPTION WHEN OTHERS THEN
   lv_error_message:=NULL;
   END;
  
  
  
   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="String">'||i.DATA_SOURCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RECORD_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ORG_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.OPERATING_UNIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ALTERNATE_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ENABLED_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_TYPE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_PAYMENT_TERMS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ONE_TIME_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_CUSTOMER_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PARENT_VENDOR_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.MIN_ORDER_AMOUNT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SET_OF_BOOKS_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAY_GROUP_LOOKUP_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_PAYMENT_PRIORITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_INVOICE_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_PAYMENT_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INVOICE_AMOUNT_LIMIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_HOLD_ALL_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_HOLD_FUTURE_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_REASON||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_DATE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.VDR_START_DATE_ACTIVE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.VDR_END_DATE_ACTIVE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDR_GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_GLOBAL_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.NI_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EDI_PAYMENT_METHOD||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.URL||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.REMITTANCE_EMAIL||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CEO_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CEO_TITLE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_CODE_ALT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ADDRESS_LINE_4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ZIP||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PROVINCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.COUNTRY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PURCHASING_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RFQ_ONLY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PRIMARY_PAY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_INVOICE_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_PAYMENT_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_HOLD_ALL_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_HOLD_FUTURE_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_HOLD_REASON||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PHONE_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EMAIL_ADDRESS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.DUNS_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_PAYMENT_PRIORITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_CUSTOMER_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.AREA_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.FAX||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.FAX_AREA_CODE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.LIABILITY_ACCOUNT||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.PREPAYMENT_ACCOUNT||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.BILLS_PAYABLE_ACCOUNT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_GLOBAL_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_PAYMENT_TERMS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LEGAL_BUSINESS_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VDRS_INVOICE_AMOUNT_LIMIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INACTIVE_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SHORT_BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_COUNTRY_CODE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.BANK_END_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE21||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE22||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE23||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE24||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ATTRIBUTE25||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_BRANCH_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EFT_SWIFT_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BIC||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.BRANCH_END_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE21||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE22||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE23||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE24||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ATTRIBUTE25||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SHORT_ACCOUNT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.IBAN||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CHECK_DIGITS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.MULTI_CURRENCY_ALLOWED_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_TYPE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_SUFFIX||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ACCOUNT_COUNTRY_CODE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.ACCOUNT_START_DATE||'</Data></Cell>
	<Cell><Data ss:Type="String">'||i.ACCOUNT_END_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANKACCOUNT_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ACCOUNT_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAN_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GST_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATUS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||lv_error_message||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CREATION_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LAST_UPDATE_DATE||'</Data></Cell>
   </Row>');
   END LOOP;
   
   fnd_file.put_line(fnd_file.output,'
      </Table>
     <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <LeftColumnVisible>249</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>4</ActiveRow>
     <ActiveCol>252</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
 
 
  --- Sheet4: Update Supplier:
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Update Supplier">
  <Table ss:ExpandedColumnCount="73" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="160.5" ss:DefaultRowHeight="15">
   <Column ss:Index="5" ss:AutoFitWidth="0" ss:Width="177"/>
   <Row ss:AutoFitHeight="0"/>
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s63"><Data ss:Type="String">Process</Data></Cell>
    <Cell><Data ss:Type="String">Update Supplier</Data></Cell>
   </Row>
   <Row ss:Index="4" ss:AutoFitHeight="0">
    <Cell ss:StyleID="s64"/>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Org ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Operating Unit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Alternate Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Enabled Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Type</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Customer Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">One Time Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Min Order Amount</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Pay Group Lookup Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment Priority</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Invoice Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Invoice Amount Limit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold All Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Future Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold reason</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Start Date Active</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">End Date Active</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">National Insurance Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">EDI Payment Method</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">URL</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Remittance Email</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">CEO Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">CEO Title</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Last Update Date</Data></Cell>
   </Row>');
   
 
   FOR i IN (SELECT * FROM xxcd_bz_sup_upd_dtls_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss')
																  ORDER BY creation_date DESC)
   LOOP
   
      lv_error_message:=NULL;
   --- Get Error Message:
   BEGIN
   SELECT  CASE WHEN error_message LIKE 'SQLAP%VENDOR%NUMBER%' THEN 'Vendor Number Is Incorrect' ELSE error_message END 
   INTO lv_error_message
   FROM xxcd_bz_sup_upd_dtls_tb
   WHERE 1=1
   AND record_id=i.record_id;
   EXCEPTION WHEN OTHERS THEN
   lv_error_message:=NULL;
   END;
  
  
   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="String">'||i.DATA_SOURCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RECORD_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ORG_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.OPERATING_UNIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ALTERNATE_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ENABLED_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_TYPE_LOOKUP_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CUSTOMER_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ONE_TIME_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.MIN_ORDER_AMOUNT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAY_GROUP_LOOKUP_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAYMENT_PRIORITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INVOICE_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAYMENT_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INVOICE_AMOUNT_LIMIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_ALL_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_FUTURE_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_REASON||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.START_DATE_ACTIVE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.END_DATE_ACTIVE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.NI_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EDI_PAYMENT_METHOD||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.URL||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.REMITTANCE_EMAIL||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CEO_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CEO_TITLE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATUS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||lv_error_message||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CREATION_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LAST_UPDATE_DATE||'</Data></Cell>
   </Row>');

   END LOOP;

  fnd_file.put_line(fnd_file.output,'
   </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <LeftColumnVisible>67</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>4</ActiveRow>
     <ActiveCol>70</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
   
   
--- Sheet5: Update Supplier Site:
 fnd_file.put_line(fnd_file.output,'
<Worksheet ss:Name="Update Supplier Site">
  <Table ss:ExpandedColumnCount="72" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="140.25" ss:DefaultRowHeight="15">
   <Row ss:AutoFitHeight="0"/>
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s63"><Data ss:Type="String">Process</Data></Cell>
    <Cell><Data ss:Type="String">Update Supplier Site</Data></Cell>
   </Row>
   <Row ss:Index="4" ss:AutoFitHeight="0">
    <Cell ss:StyleID="s64"/>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Org ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Operating Unit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site Name Alt</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Purchasing Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">REQ Only Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Pay site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Primary Pay Site Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Invoice Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment Currency Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold All Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Future Payments Flag</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Hold Reason</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Phone Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Email Address</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">DUNS Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment Priority</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Customer Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Area Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Fax </Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Fax Area Code</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Global Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Payment Terms</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Legal Business Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Invoice Amount Limit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Inactive Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Last Update Date</Data></Cell>
   </Row>'); 
   
   
   FOR i IN (SELECT * FROM xxcd_bz_sup_site_upd_dtls_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss')
																  ORDER BY creation_date DESC)
   LOOP
   
      lv_error_message:=NULL;
   --- Get Error Message:
   BEGIN
   SELECT  CASE WHEN error_message LIKE 'SQLAP%VENDOR%NUMBER%' THEN 'Vendor Number Is Incorrect' ELSE error_message END 
   INTO lv_error_message
   FROM xxcd_bz_sup_site_upd_dtls_tb
   WHERE 1=1
   AND record_id=i.record_id;
   EXCEPTION WHEN OTHERS THEN
   lv_error_message:=NULL;
   END;
  
  
   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="String">'||i.DATA_SOURCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RECORD_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ORG_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.OPERATING_UNIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ALT_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PURCHASING_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RFQ_ONLY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PRIMARY_PAY_SITE_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INVOICE_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAYMENT_CURRENCY_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_ALL_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_FUTURE_PAYMENTS_FLAG||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.HOLD_REASON||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PHONE_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EMAIL_ADDRESS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.DUNS_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAYMENT_PRIORITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CUSTOMER_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.AREA_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.FAX||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.FAX_AREA_CODE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.GLOBAL_ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PAYMENT_TERMS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LEGAL_BUSINESS_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INVOICE_AMOUNT_LIMIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.INACTIVE_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATUS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||lv_error_message||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CREATION_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LAST_UPDATE_DATE||'</Data></Cell>
   </Row>');

   END LOOP;
   
      fnd_file.put_line(fnd_file.output,'
	  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <LeftColumnVisible>65</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>4</ActiveRow>
     <ActiveCol>69</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
 
 
    --- Sheet6: Update Supplier Site Address:
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Update Supplier Site Address">
  <Table ss:ExpandedColumnCount="22" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="98.25" ss:DefaultRowHeight="15">
   <Row ss:AutoFitHeight="0"/>
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s63"><Data ss:Type="String">Process</Data></Cell>
    <Cell><Data ss:Type="String">Update Supplier Site Address</Data></Cell>
   </Row>
   <Row ss:Index="4" ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s65"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Org ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Operating Unit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Vendor Site Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Address Line4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">City</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">State</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">ZIP</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Province</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Country</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Last Update Date</Data></Cell>
   </Row>');
   
    FOR i IN (SELECT * FROM XXCD_BZ_SUP_SITE_ADDR_UPD_TB WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss')
																  ORDER BY creation_date DESC)
   LOOP

   lv_error_message:=NULL;
   --- Get Error Message:
   BEGIN
   SELECT  CASE WHEN error_message LIKE 'SQLAP%VENDOR%NUMBER%' THEN 'Vendor Number Is Incorrect' ELSE error_message END 
   INTO lv_error_message
   FROM xxcd_bz_sup_site_addr_upd_tb
   WHERE 1=1
   AND record_id=i.record_id;
   EXCEPTION WHEN OTHERS THEN
   lv_error_message:=NULL;
   END;
  
  
   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="String">'||i.DATA_SOURCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RECORD_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ORG_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.OPERATING_UNIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.VENDOR_SITE_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.address_line1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.address_line2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.address_line3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.address_line4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CITY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ZIP||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.PROVINCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.COUNTRY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATUS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||lv_error_message||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CREATION_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LAST_UPDATE_DATE||'</Data></Cell>
   </Row>');

   END LOOP;

   fnd_file.put_line(fnd_file.output,'
     </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <LeftColumnVisible>12</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>4</ActiveRow>
     <ActiveCol>19</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
 
 
  --- Sheet7: Update Bank:
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Update Bank">
  <Table ss:ExpandedColumnCount="41" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="108.75" ss:DefaultRowHeight="15">
   <Column ss:Index="12" ss:AutoFitWidth="0" ss:Width="138"/>
   <Row ss:AutoFitHeight="0"/>
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s63"><Data ss:Type="String">Process</Data></Cell>
    <Cell><Data ss:Type="String">Update Bank</Data></Cell>
   </Row>
   <Row ss:Index="4" ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s65"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Operating Unit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Bank Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Short Bank Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Country</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Tax Registration Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute21</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute22</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute23</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute24</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Last Update date</Data></Cell>
   </Row>');
   
    FOR i IN (SELECT * FROM XXCD_BZ_BANK_UPD_TB WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss')
																  ORDER BY creation_date DESC)
   LOOP
   
      lv_error_message:=NULL;
   --- Get Error Message:
   BEGIN
   SELECT  CASE WHEN error_message LIKE 'SQLAP%VENDOR%NUMBER%' THEN 'Vendor Number Is Incorrect' ELSE error_message END 
   INTO lv_error_message
   FROM xxcd_bz_bank_upd_tb
   WHERE 1=1
   AND record_id=i.record_id;
   EXCEPTION WHEN OTHERS THEN
   lv_error_message:=NULL;
   END;
  

   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="String">'||i.RECORD_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.DATA_SOURCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.OPERATING_UNIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BANK_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.SHORT_BANK_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.COUNTRY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.TAX_REGISTRATION_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE21||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE22||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE23||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE24||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATUS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||lv_error_message||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CREATION_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LAST_UPDATE_DATE||'</Data></Cell>
   </Row>');
   END LOOP;

   fnd_file.put_line(fnd_file.output,'
   </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <LeftColumnVisible>32</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>4</ActiveRow>
     <ActiveCol>38</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
   
   --- Sheet8: Update Bank Branch:
 fnd_file.put_line(fnd_file.output,'
<Worksheet ss:Name="Update Bank Branch">
  <Table ss:ExpandedColumnCount="42" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="104.25" ss:DefaultRowHeight="15">
   <Column ss:Index="9" ss:AutoFitWidth="0" ss:Width="127.5"/>
   <Row ss:AutoFitHeight="0"/>
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s63"><Data ss:Type="String">Process</Data></Cell>
    <Cell><Data ss:Type="String">Update Bank Branch</Data></Cell>
   </Row>
   <Row ss:Index="4" ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s65"><Data ss:Type="String">Record ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Data Source</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Operating Unit</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch ID</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Branch Type</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Alternate Branch Name</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Description</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">BIC</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">EFT Number</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">RFC Identifier</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute Category</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute1</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute2</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute3</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute4</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute5</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute6</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute7</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute8</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute9</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute10</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute11</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute12</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute13</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute14</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute15</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute16</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute17</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute18</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute19</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute20</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute21</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute22</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute23</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Attribute24</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Status</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Error Message</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Creation Date</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Last Update Date</Data></Cell>
   </Row>');

FOR i IN (SELECT * FROM XXCD_BZ_BRANCH_UPD_TB WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss')
																  ORDER BY CREATION_DATE DESC)
   LOOP

   lv_error_message:=NULL;
   --- Get Error Message:
   BEGIN
   SELECT  CASE WHEN error_message LIKE 'SQLAP%VENDOR%NUMBER%' THEN 'Vendor Number Is Incorrect' ELSE error_message END 
   INTO lv_error_message
   FROM xxcd_bz_branch_upd_tb
   WHERE 1=1
   AND record_id=i.record_id;
   EXCEPTION WHEN OTHERS THEN
   lv_error_message:=NULL;
   END;
  
  
   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="String">'||i.RECORD_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.DATA_SOURCE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.OPERATING_UNIT||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_ID||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BRANCH_TYPE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ALTERNATE_BRANCH_NAME||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.DESCRIPTION||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.BIC||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.EFT_NUMBER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.RFC_IDENTIFIER||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE_CATEGORY||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE1||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE2||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE3||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE4||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE5||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE6||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE7||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE8||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE9||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE10||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE11||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE12||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE13||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE14||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE15||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE16||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE17||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE18||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE19||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE20||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE21||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE22||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE23||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.ATTRIBUTE24||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.STATUS||'</Data></Cell>
    <Cell><Data ss:Type="String">'||lv_error_message||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.CREATION_DATE||'</Data></Cell>
    <Cell><Data ss:Type="String">'||i.LAST_UPDATE_DATE||'</Data></Cell>
   </Row>');

   END LOOP;

   fnd_file.put_line(fnd_file.output,'
</Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <LeftColumnVisible>33</LeftColumnVisible>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>4</ActiveRow>
     <ActiveCol>39</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
 
   --- Sheet12: Summary:
 fnd_file.put_line(fnd_file.output,'
 <Worksheet ss:Name="Summary">
  <Table ss:ExpandedColumnCount="6" ss:ExpandedRowCount="100000" x:FullColumns="1"
   x:FullRows="1" ss:DefaultRowHeight="15">
   <Column ss:Index="3" ss:AutoFitWidth="0" ss:Width="321"/>
   <Column ss:AutoFitWidth="0" ss:Width="110.25"/>
   <Column ss:AutoFitWidth="0" ss:Width="116.25"/>
   <Column ss:AutoFitWidth="0" ss:Width="105"/>
   <Row ss:AutoFitHeight="0"/>
   <Row ss:Index="4" ss:AutoFitHeight="0">
    <Cell ss:Index="2" ss:StyleID="s65"><Data ss:Type="String">Sno</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Process</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Total No.of. Records</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Total Success Records</Data></Cell>
    <Cell ss:StyleID="s65"><Data ss:Type="String">Total Failure Records</Data></Cell>
   </Row>');
   
   
lv_total:=0;

BEGIN
SELECT COUNT(*) INTO lv_total FROM xxcd_bz_sup_all_mst_crt_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss');
EXCEPTION WHEN OTHERS THEN
lv_total:=0;
END;

lv_success:=0;
BEGIN
SELECT COUNT(*) INTO lv_success FROM xxcd_bz_sup_all_mst_crt_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status='SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_success:=0;
END;

lv_failure:=0;
BEGIN
SELECT COUNT(*) INTO lv_failure FROM xxcd_bz_sup_all_mst_crt_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status<>'SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_failure:=0;
END;

fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="Number">1</Data></Cell>
    <Cell><Data ss:Type="String">Supplier All Master Creation</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_success||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_failure||'</Data></Cell>
   </Row>');

lv_total:=0;

BEGIN
SELECT COUNT(*) INTO lv_total FROM xxcd_bz_sup_site_mst_crt_tb  WHERE 1=1 AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') ;
EXCEPTION WHEN OTHERS THEN
lv_total:=0;
END;

lv_success:=0;
BEGIN
SELECT COUNT(*) INTO lv_success FROM xxcd_bz_sup_site_mst_crt_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status='SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_success:=0;
END;

lv_failure:=0;
BEGIN
SELECT COUNT(*) INTO lv_failure FROM xxcd_bz_sup_site_mst_crt_tb WHERE 1=1   AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss')AND status<>'SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_failure:=0;
END;

   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="Number">2</Data></Cell>
    <Cell><Data ss:Type="String">Existing Supplier New Site Creation</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_success||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_failure||'</Data></Cell>
   </Row>');



lv_total:=0;

BEGIN
SELECT COUNT(*) INTO lv_total FROM xxcd_bz_bank_crt_dtls_tb  WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss');
EXCEPTION WHEN OTHERS THEN
lv_total:=0;
END;

lv_success:=0;
BEGIN
SELECT COUNT(*) INTO lv_success FROM xxcd_bz_bank_crt_dtls_tb  WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status='SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_success:=0;
END;

lv_failure:=0;
BEGIN
SELECT COUNT(*) INTO lv_failure FROM xxcd_bz_bank_crt_dtls_tb  WHERE 1=1   AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status<>'SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_failure:=0;
END;

   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="Number">3</Data></Cell>
    <Cell><Data ss:Type="String">Existing Supplier New Bank, Branch and Bank Account Creation</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_success||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_failure||'</Data></Cell>
   </Row>');



lv_total:=0;

BEGIN
SELECT COUNT(*) INTO lv_total FROM xxcd_bz_sup_upd_dtls_tb  WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss');
EXCEPTION WHEN OTHERS THEN
lv_total:=0;
END;

lv_success:=0;
BEGIN
SELECT COUNT(*) INTO lv_success FROM xxcd_bz_sup_upd_dtls_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status='SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_success:=0;
END;

lv_failure:=0;
BEGIN
SELECT COUNT(*) INTO lv_failure FROM xxcd_bz_sup_upd_dtls_tb  WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status<>'SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_failure:=0;
END;

fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="Number">4</Data></Cell>
    <Cell><Data ss:Type="String">Update Supplier</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_success||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_failure||'</Data></Cell>
   </Row>');



lv_total:=0;

BEGIN
SELECT COUNT(*) INTO lv_total FROM xxcd_bz_sup_site_upd_dtls_tb  WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss');
EXCEPTION WHEN OTHERS THEN
lv_total:=0;
END;

lv_success:=0;
BEGIN
SELECT COUNT(*) INTO lv_success FROM xxcd_bz_sup_site_upd_dtls_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status='SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_success:=0;
END;

lv_failure:=0;
BEGIN
SELECT COUNT(*) INTO lv_failure FROM xxcd_bz_sup_site_upd_dtls_tb  WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status<>'SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_failure:=0;
END;

   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="Number">5</Data></Cell>
    <Cell><Data ss:Type="String">Update Supplier Site</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_success||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_failure||'</Data></Cell>
   </Row>');



lv_total:=0;

BEGIN
SELECT COUNT(*) INTO lv_total FROM xxcd_bz_sup_site_addr_upd_tb  WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss');
EXCEPTION WHEN OTHERS THEN
lv_total:=0;
END;

lv_success:=0;
BEGIN
SELECT COUNT(*) INTO lv_success FROM xxcd_bz_sup_site_addr_upd_tb  WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status='SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_success:=0;
END;

lv_failure:=0;
BEGIN
SELECT COUNT(*) INTO lv_failure FROM xxcd_bz_sup_site_addr_upd_tb   WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status<>'SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_failure:=0;
END;


   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="Number">6</Data></Cell>
    <Cell><Data ss:Type="String">Update Supplier Site Address</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_success||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_failure||'</Data></Cell>
   </Row>');



lv_total:=0;

BEGIN
SELECT COUNT(*) INTO lv_total FROM xxcd_bz_bank_upd_tb  WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss');
EXCEPTION WHEN OTHERS THEN
lv_total:=0;
END;

lv_success:=0;
BEGIN
SELECT COUNT(*) INTO lv_success FROM xxcd_bz_bank_upd_tb  WHERE 1=1   AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status='SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_success:=0;
END;

lv_failure:=0;
BEGIN
SELECT COUNT(*) INTO lv_failure FROM xxcd_bz_bank_upd_tb   WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status<>'SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_failure:=0;
END;

   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="Number">7</Data></Cell>
    <Cell><Data ss:Type="String">Update Bank</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_success||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_failure||'</Data></Cell>
   </Row>');



lv_total:=0;

BEGIN
SELECT COUNT(*) INTO lv_total FROM xxcd_bz_branch_upd_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss');
EXCEPTION WHEN OTHERS THEN
lv_total:=0;
END;

lv_success:=0;
BEGIN
SELECT COUNT(*) INTO lv_success FROM xxcd_bz_branch_upd_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status='SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_success:=0;
END;

lv_failure:=0;
BEGIN
SELECT COUNT(*) INTO lv_failure FROM xxcd_bz_branch_upd_tb WHERE 1=1  AND TRUNC(creation_date) BETWEEN TO_DATE(p_from_date, 'yyyy/mm/dd hh24:mi:ss')
                                                                  AND TO_DATE(p_to_date, 'yyyy/mm/dd hh24:mi:ss') AND status<>'SUCCESS';
EXCEPTION WHEN OTHERS THEN
lv_failure:=0;
END;

   fnd_file.put_line(fnd_file.output,'
   <Row ss:AutoFitHeight="0">
    <Cell ss:Index="2"><Data ss:Type="Number">8</Data></Cell>
    <Cell><Data ss:Type="String">Update Bank Branch</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_total||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_success||'</Data></Cell>
    <Cell><Data ss:Type="Number">'||lv_failure||'</Data></Cell>
   </Row>');

   fnd_file.put_line(fnd_file.output,'
  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <PageSetup>
    <Header x:Margin="0.3"/>
    <Footer x:Margin="0.3"/>
    <PageMargins x:Bottom="0.75" x:Left="0.7" x:Right="0.7" x:Top="0.75"/>
   </PageSetup>
   <Unsynced/>
   <Selected/>
   <Panes>
    <Pane>
     <Number>3</Number>
     <ActiveRow>18</ActiveRow>
     <ActiveCol>2</ActiveCol>
    </Pane>
   </Panes>
   <ProtectObjects>False</ProtectObjects>
   <ProtectScenarios>False</ProtectScenarios>
  </WorksheetOptions>
 </Worksheet>');
 
fnd_file.put_line(fnd_file.output,'</Workbook>');

END;