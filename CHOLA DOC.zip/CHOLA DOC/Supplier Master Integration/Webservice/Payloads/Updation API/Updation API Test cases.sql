
Supplier Updation API test cases:
----------------------------------

Case1: Update Supplier,Site,Bank,Branch
========================================
Supplier: MAHINDRRA SUP
Supplier Site:  CHENNAI
Bank: MAHINDRRA IDFC Bank
Bank Branch:MAHINDRRA IDFC BANK BRANCH
Bank Account Name:MAHINDRRA IDFC BANK ACCOUNT
Bank Account Number:MAHINDRRAIDFC1234567890

Vendor ID, Vendor Name , Vendor Number ,Vendor Site ID,Vendor Site code is mandatory