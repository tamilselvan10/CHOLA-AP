URL:http://preprodr12app.chola.murugappa.com:8030/webservices/rest/upd_all_supplier_master_data/update_supplier_all_master/

Method: POST

Basic Authentication:
-----------------------
username:bazuser
pwd:oracle1234


Case1: Update Supplier,Site,Bank,Branch
========================================
Supplier: MAHINDRRA SUP
Supplier Site:  CHENNAI
Bank: MAHINDRRA IDFC Bank
Bank Branch:MAHINDRRA IDFC BANK BRANCH
Bank Account Name:MAHINDRRA IDFC BANK ACCOUNT
Bank Account Number:MAHINDRRAIDFC1234567890

Vendor ID, Vendor Name , Vendor Number ,Vendor Site ID,Vendor Site code is mandatory

Request Payload:
----------------
{
	"UPDATE_SUPPLIER_ALL_MASTER_Input": {
		"@xmlns": "http://xmlns.oracle.com/apps/ap/rest/upd_all_supplier_master_data/update_supplier_all_master/",
		"RESTHeader": {
			"@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
		},
		"InputParameters": {
			"DATA": {
				"DATA_ITEM": [
					{
                       "DATA_SOURCE": "BAZ",
                        "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
						"VENDOR_ID": 6686829,
                        "VENDOR_NAME": "MAHINDRRA SUP",
                        "VENDOR_NUMBER": "213887",
                        "VENDOR_ALTERNATE_NAME": null,
                        "VENDOR_TYPE": "VENDOR",
                        "VENDOR_PAYMENT_TERMS": "IMMEDIATE",
                        "ENABLED_FLAG": "Y",
                        "ONE_TIME_FLAG": "Y",
                        "VDR_CUSTOMER_NUMBER": null,
                        "PARENT_VENDOR_ID": null,
                        "MIN_ORDER_AMOUNT": null,
                        "SET_OF_BOOKS_NAME": null,
                        "PAY_GROUP_LOOKUP_CODE": null,
                        "VDR_PAYMENT_PRIORITY": 99,
                        "VDR_INVOICE_CURRENCY_CODE": "INR",
                        "VDR_PAYMENT_CURRENCY_CODE": "INR",
                        "INVOICE_AMOUNT_LIMIT": null,
                        "VDR_HOLD_ALL_PAYMENTS_FLAG": "N",
                        "VDR_HOLD_FUTURE_PAYMENTS_FLAG": "N",
                        "HOLD_REASON": null,
                        "HOLD_FLAG": "N",
                        "HOLD_DATE": null,
                        "VDR_START_DATE_ACTIVE":null,
                        "VDR_END_DATE_ACTIVE":null,
                        "VENDOR_ATTRIBUTE_CATEGORY": null,
                        "VENDOR_ATTRIBUTE1": null,
                        "VENDOR_ATTRIBUTE2": null,
                        "VENDOR_ATTRIBUTE15": "Y",
                        "NI_NUMBER": null,
                        "EDI_PAYMENT_METHOD": null,
                        "URL": null,
                        "REMITTANCE_EMAIL": null,
                        "CEO_NAME": null,
                        "CEO_TITLE": null,
						"VENDOR_SITE_ID":431385,
                        "VENDOR_SITE_CODE": "CHENNAI",
                        "VENDOR_SITE_CODE_ALT": "CHENNAI_SITE",
                        "ADDRESS_LINE_1": "ADDRESS LINE19223",
                        "ADDRESS_LINE_2": "ADDRESS LINE2",
                        "ADDRESS_LINE_3": "ADDRESS LINE3",
                        "ADDRESS_LINE_4": "ADDRESS LINE4",
                        "CITY": "TAMIL NADU",
                        "STATE": "TAMIL NADU",
                        "ZIP": "606601",
                        "PROVINCE": null,
                        "COUNTRY": "IN",
                        "PURCHASING_SITE_FLAG": "Y",
                        "RFQ_ONLY_SITE_FLAG": "Y",
                        "PAY_SITE_FLAG": "Y",
                        "PRIMARY_PAY_SITE_FLAG": "N",
                        "VDRS_INVOICE_CURRENCY_CODE": "INR",
                        "VDRS_PAYMENT_CURRENCY_CODE": "INR",
                        "VDRS_HOLD_ALL_PAYMENTS_FLAG": "N",
                        "VDRS_HOLD_FUTURE_PAYMENTS_FLAG": "N",
                        "VDRS_HOLD_REASON": null,
                        "PHONE_NUMBER": "1234567831",
                        "EMAIL_ADDRESS": "abc1@gmail.com",
                        "DUNS_NUMBER": null,
                        "VDRS_PAYMENT_PRIORITY": null,
                        "VDRS_CUSTOMER_NUMBER": null,
                        "AREA_CODE": null,
                        "FAX": null,
                        "FAX_AREA_CODE": null,
                        "LIABILITY_ACCOUNT":null,
                        "PREPAYMENT_ACCOUNT":null,
                        "BILLS_PAYABLE_ACCOUNT":null,
                        "VENDOR_SITE_PAYMENT_TERMS": "TDS",
                        "LEGAL_BUSINESS_NAME": null,
                        "VDRS_INVOICE_AMOUNT_LIMIT": null,
                        "INACTIVE_DATE": null,
						"BANK_ID":null,
                        "BANK_NAME": "MAHINDRRA IDFC Bank",
                        "ALTERNATE_BANK_NAME": "MAHINDRRA IDFC Bank",
                        "SHORT_BANK_NAME": null,
                        "BANK_DESCRIPTION": null,
                        "BANK_NUMBER": null,
                        "BANK_COUNTRY_CODE": "IN",
						"BRANCH_ID":null,
                        "BRANCH_NAME": "MAHINDRRA IDFC BANK BRANCH",
                        "ALTERNATE_BRANCH_NAME":"MAHINDRRA IDFC BANK BRANCH ALLT",
                        "BRANCH_NUMBER": null,
                        "BRANCH_DESCRIPTION": "BRENDTST",
                        "EFT_SWIFT_CODE": null,
                        "BIC": null,
						"BANK_ACCOUNT_ID":null,
                        "BANK_ACCOUNT_NAME": "MAHINDRRA IDFC BANK ACCOUNT",
                        "ALTERNATE_ACCOUNT_NAME": null,
                        "SHORT_ACCOUNT_NAME": null,
                        "BANK_ACCOUNT_NUMBER": "MAHINDRRAIDFC1234567890",
                        "CURRENCY_CODE": "INR",
                        "IBAN": null,
                        "CHECK_DIGITS": null,
                        "MULTI_CURRENCY_ALLOWED_FLAG": "Y",
                        "ACCOUNT_TYPE": null,
                        "ACCOUNT_SUFFIX": null,
                        "ACCOUNT_DESCRIPTION": null,
                        "ACCOUNT_COUNTRY_CODE": "IN",
                        "BANK_ACCOUNT_ATTRIBUTE3": "IFSC1234",
                        "PAN_NUMBER": "ABCDE1234J",
                        "GST_NUMBER": "GST1234567895"
                    }
				]
			}
		}
	}
}

Response Payload:
------------------
{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/upd_all_supplier_master_data/update_supplier_all_master/",
        "TIMESTAMP": "20-JAN-2023 16:35:12",
        "STATUS": "SUCCESS",
        "MESSAGE": "Supplier Data Updated Successfully,Supplier Site Data Updated Successfully,Supplier Site Address Updated Successfully,Bank data updated successfully,Branch data updated successfully",
        "VENDOR_ID": "6686829",
        "VENDOR_NUMBER": "213887",
        "VENDOR_SITE_ID": "431385",
        "BANK_ID": "7451147",
        "BRANCH_ID": "7451149",
        "BANK_ACCOUNT_ID": "142055"
    }
}