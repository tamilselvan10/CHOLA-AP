

Supplier Creation API Test cases:
-----------------------------------

Case1: New Supplier, Site, Bank, Branch and Bank Account Creation
=================================================================
Supplier: MAHINDRRA SUP
Supplier Site:  CHENNAI
Bank: MAHINDRRA IDFC Bank
Bank Branch:MAHINDRRA IDFC BANK BRANCH
Bank Account Name:MAHINDRRA IDFC BANK ACCOUNT
Bank Account Number:MAHINDRRAIDFC1234567890


Case2: Existing Supplier New Site
==================================

Supplier: MAHINDRRA SUP
Supplier Site: MADURAI

Vendor ID,Vendor Name AND Vendor Number IS Mandatory

Case 3: Existing Supplier Site new bank, new branch, new account
====================================================================

Supplier: MAHINDRRA SUP
Supplier Site:  CHENNAI
Bank: MAHINDRRA AXIS Bank
Bank Branch:MAHINDRRA AXIS BANK BRANCH
Bank Account Name:MAHINDRRA AXIS BANK ACCOUNT
Bank Account Number:MAHINDRRAAXIS1234567890

Vendor ID,Vendor Name ,Vendor Number, Vendor Site ID  and Vendor Site code is mandatory

Case 4: Existing Supplier New Site, new bank, new branch, new bank account
============================================================================

Supplier: MAHINDRRA SUP
Supplier Site:  BANGALORE
Bank: MAHINDRRA YES Bank
Bank Branch:MAHINDRRA YES BANK BRANCH
Bank Account Name:MAHINDRRA YES BANK ACCOUNT
Bank Account Number:MAHINDRRAYES1234567890

Vendor ID,Vendor Name and Vendor Number is mandatory


Case 5: Existing supplier,bank,branch and bank account with new site(WIP)
=========================================================================

Supplier: MAHINDRRA SUP
Supplier Site:  GOA
Bank: MAHINDRRA YES Bank
Bank Branch:MAHINDRRA YES BANK BRANCH
Bank Account Name:MAHINDRRA YES BANK ACCOUNT
Bank Account Number:MAHINDRRAYES1234567890

Vendor ID,Vendor Name,Vendor Number is Mandatory

Case 6: New supplier and Site, Without Passing bank,branch and bank account
=========================================================================

Supplier: MAHINDRRA SUP
Supplier Site:  GOA
Bank: null
Bank Branch: null
Bank Account Name: null
Bank Account Number: null

Vendor Name,Vendor Site Name is Mandatory