
URL:	http://preprodr12app.chola.murugappa.com:8030/webservices/rest/crt_all_supplier_master/create_supplier_all_master/

Basic Authentication:
-----------------------
username:bazuser
pwd:oracle1234

Case1: New Supplier, Site, Bank, Branch and Bank Account Creation
=================================================================
Supplier: MAHINDRRA SUP
Supplier Site:  CHENNAI
Bank: MAHINDRRA IDFC Bank
Bank Branch:MAHINDRRA IDFC BANK BRANCH
Bank Account Name:MAHINDRRA IDFC BANK ACCOUNT
Bank Account Number:MAHINDRRAIDFC1234567890

Request Payload:
---------------

{
    "CREATE_SUPPLIER_ALL_MASTER_Input": {
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "RESTHeader": {
            "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
        },
        "InputParameters": {
            "DATA": {
                "DATA_ITEM": [
                    {
                        "DATA_SOURCE": "BAZ",
                        "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
						"VENDOR_ID": null,
                        "VENDOR_NAME": "MAHINDRRA SUP",
                        "VENDOR_NUMBER": null,
                        "VENDOR_ALTERNATE_NAME": "MAHINDRRA SUP ALT",
                        "VENDOR_TYPE": "VENDOR",
                        "VENDOR_PAYMENT_TERMS": "IMMEDIATE",
                        "ENABLED_FLAG": "Y",
                        "ONE_TIME_FLAG": "Y",
                        "VDR_CUSTOMER_NUMBER": null,
                        "PARENT_VENDOR_ID": null,
                        "MIN_ORDER_AMOUNT": null,
                        "SET_OF_BOOKS_NAME": null,
                        "PAY_GROUP_LOOKUP_CODE": null,
                        "VDR_PAYMENT_PRIORITY": 99,
                        "VDR_INVOICE_CURRENCY_CODE": null,
                        "VDR_PAYMENT_CURRENCY_CODE": null,
                        "INVOICE_AMOUNT_LIMIT": null,
                        "VDR_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDR_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "HOLD_REASON": null,
                        "HOLD_FLAG": null,
                        "HOLD_DATE": null,
                        "VDR_START_DATE_ACTIVE":null,
                        "VDR_END_DATE_ACTIVE":null,
                        "VENDOR_ATTRIBUTE_CATEGORY": null,
                        "VENDOR_ATTRIBUTE1": null,
                        "VENDOR_ATTRIBUTE2": null,
                        "VENDOR_ATTRIBUTE15": "Y",
                        "NI_NUMBER": null,
                        "EDI_PAYMENT_METHOD": null,
                        "URL": null,
                        "REMITTANCE_EMAIL": null,
                        "CEO_NAME": null,
                        "CEO_TITLE": null,
						"VENDOR_SITE_ID":null,
                        "VENDOR_SITE_CODE": "CHENNAI",
                        "VENDOR_SITE_CODE_ALT": "ALT_CHENNAI",
                        "ADDRESS_LINE_1": "ADDRESS LINE19223",
                        "ADDRESS_LINE_2": "ADDRESS LINE2",
                        "ADDRESS_LINE_3": "ADDRESS LINE3",
                        "ADDRESS_LINE_4": "ADDRESS LINE4",
                        "CITY": "TAMIL NADU",
                        "STATE": "TAMIL NADU",
                        "ZIP": "606601",
                        "PROVINCE": null,
                        "COUNTRY": "IN",
                        "PURCHASING_SITE_FLAG": "Y",
                        "RFQ_ONLY_SITE_FLAG": "Y",
                        "PAY_SITE_FLAG": "Y",
                        "PRIMARY_PAY_SITE_FLAG": "N",
                        "VDRS_INVOICE_CURRENCY_CODE": null,
                        "VDRS_PAYMENT_CURRENCY_CODE": null,
                        "VDRS_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_REASON": null,
                        "PHONE_NUMBER": "1234567831",
                        "EMAIL_ADDRESS": "abc1@gmail.com",
                        "DUNS_NUMBER": null,
                        "VDRS_PAYMENT_PRIORITY": null,
                        "VDRS_CUSTOMER_NUMBER": null,
                        "AREA_CODE": null,
                        "FAX": null,
                        "FAX_AREA_CODE": null,
                        "LIABILITY_ACCOUNT":null,
                        "PREPAYMENT_ACCOUNT":null,
                        "BILLS_PAYABLE_ACCOUNT":null,
                        "VENDOR_SITE_PAYMENT_TERMS": "IMMEDIATE",
                        "LEGAL_BUSINESS_NAME": null,
                        "VDRS_INVOICE_AMOUNT_LIMIT": null,
                        "INACTIVE_DATE": null,
						"BANK_ID":null,
                        "BANK_NAME": "MAHINDRRA IDFC Bank",
                        "ALTERNATE_BANK_NAME": "MAHINDRRA IDFC Bank",
                        "SHORT_BANK_NAME": "IDFC",
                        "BANK_DESCRIPTION": "MAHINDRRA IDFC Bank",
                        "BANK_NUMBER": null,
                        "BANK_COUNTRY_CODE": "IN",
						"BRANCH_ID":null,
                        "BRANCH_NAME": "MAHINDRRA IDFC BANK BRANCH",
                        "ALTERNATE_BRANCH_NAME": "MAHINDRRA IDFC BANK BRANCH Alt",
                        "BRANCH_NUMBER": null,
                        "BRANCH_DESCRIPTION": "MAHINDRRA IDFC BANK BRANCH",
                        "EFT_SWIFT_CODE": null,
                        "BIC": null,
						"BANK_ACCOUNT_ID":null,
                        "BANK_ACCOUNT_NAME": "MAHINDRRA IDFC BANK ACCOUNT",
                        "ALTERNATE_ACCOUNT_NAME": "MAHINDRRA IDFC BANK ACCOUNT ALT",
                        "SHORT_ACCOUNT_NAME": null,
                        "BANK_ACCOUNT_NUMBER": "MAHINDRRAIDFC1234567890",
                        "CURRENCY_CODE": "INR",
                        "IBAN": null,
                        "CHECK_DIGITS": null,
                        "MULTI_CURRENCY_ALLOWED_FLAG": "Y",
                        "ACCOUNT_TYPE": null,
                        "ACCOUNT_SUFFIX": null,
                        "ACCOUNT_DESCRIPTION": null,
                        "ACCOUNT_COUNTRY_CODE": "IN",
                        "BANK_ACCOUNT_ATTRIBUTE3": "IFSC1234",
                        "PAN_NUMBER": "ABCDE1234M",
                        "GST_NUMBER": "GST1234567898"
                    }
                ]
            }
        }
    }
}

Response Payload:
------------------

{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "TIMESTAMP": "20-JAN-2023 15:24:14",
        "STATUS": "SUCCESS",
        "MESSAGE": {
            "@xsi:nil": "true"
        },
        "VENDOR_ID": "6686829",
        "VENDOR_NUMBER": "213887",
        "VENDOR_SITE_ID": "431385",
        "BANK_ID": "7451147",
        "BRANCH_ID": "7451149",
        "BANK_ACCOUNT_ID": "142055"
    }
}

/*********************************************************************************************************************************/

Case2: Existing Supplier New Site

Supplier: MAHINDRRA SUP
Supplier Site: MADURAI

Vendor ID,Vendor Name AND Vendor Number IS MANDATORY

Request payload:
-----------------
{
    "CREATE_SUPPLIER_ALL_MASTER_Input": {
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "RESTHeader": {
            "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
        },
        "InputParameters": {
            "DATA": {
                "DATA_ITEM": [
                    {
                        "DATA_SOURCE": "BAZ",
                        "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
						"VENDOR_ID": 6686829,
                        "VENDOR_NAME": "MAHINDRRA SUP",
                        "VENDOR_NUMBER": "213887",
                        "VENDOR_ALTERNATE_NAME": "MAHINDRRA SUP ALT",
                        "VENDOR_TYPE": "VENDOR",
                        "VENDOR_PAYMENT_TERMS": "IMMEDIATE",
                        "ENABLED_FLAG": "Y",
                        "ONE_TIME_FLAG": "Y",
                        "VDR_CUSTOMER_NUMBER": null,
                        "PARENT_VENDOR_ID": null,
                        "MIN_ORDER_AMOUNT": null,
                        "SET_OF_BOOKS_NAME": null,
                        "PAY_GROUP_LOOKUP_CODE": null,
                        "VDR_PAYMENT_PRIORITY": 99,
                        "VDR_INVOICE_CURRENCY_CODE": null,
                        "VDR_PAYMENT_CURRENCY_CODE": null,
                        "INVOICE_AMOUNT_LIMIT": null,
                        "VDR_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDR_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "HOLD_REASON": null,
                        "HOLD_FLAG": null,
                        "HOLD_DATE": null,
                        "VDR_START_DATE_ACTIVE":null,
                        "VDR_END_DATE_ACTIVE":null,
                        "VENDOR_ATTRIBUTE_CATEGORY": null,
                        "VENDOR_ATTRIBUTE1": null,
                        "VENDOR_ATTRIBUTE2": null,
                        "VENDOR_ATTRIBUTE15": "Y",
                        "NI_NUMBER": null,
                        "EDI_PAYMENT_METHOD": null,
                        "URL": null,
                        "REMITTANCE_EMAIL": null,
                        "CEO_NAME": null,
                        "CEO_TITLE": null,
						"VENDOR_SITE_ID":null,
                        "VENDOR_SITE_CODE": "MADURAI",
                        "VENDOR_SITE_CODE_ALT": "ALT_MADURAI",
                        "ADDRESS_LINE_1": "ADDRESS LINE19223",
                        "ADDRESS_LINE_2": "ADDRESS LINE2",
                        "ADDRESS_LINE_3": "ADDRESS LINE3",
                        "ADDRESS_LINE_4": "ADDRESS LINE4",
                        "CITY": "TAMIL NADU",
                        "STATE": "TAMIL NADU",
                        "ZIP": "606601",
                        "PROVINCE": null,
                        "COUNTRY": "IN",
                        "PURCHASING_SITE_FLAG": "Y",
                        "RFQ_ONLY_SITE_FLAG": "Y",
                        "PAY_SITE_FLAG": "Y",
                        "PRIMARY_PAY_SITE_FLAG": "N",
                        "VDRS_INVOICE_CURRENCY_CODE": null,
                        "VDRS_PAYMENT_CURRENCY_CODE": null,
                        "VDRS_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_REASON": null,
                        "PHONE_NUMBER": "1234567831",
                        "EMAIL_ADDRESS": "abc1@gmail.com",
                        "DUNS_NUMBER": null,
                        "VDRS_PAYMENT_PRIORITY": null,
                        "VDRS_CUSTOMER_NUMBER": null,
                        "AREA_CODE": null,
                        "FAX": null,
                        "FAX_AREA_CODE": null,
                        "LIABILITY_ACCOUNT":null,
                        "PREPAYMENT_ACCOUNT":null,
                        "BILLS_PAYABLE_ACCOUNT":null,
                        "VENDOR_SITE_PAYMENT_TERMS": "IMMEDIATE",
                        "LEGAL_BUSINESS_NAME": null,
                        "VDRS_INVOICE_AMOUNT_LIMIT": null,
                        "INACTIVE_DATE": null,
						"BANK_ID":null,
                        "BANK_NAME": null,
                        "ALTERNATE_BANK_NAME": null,
                        "SHORT_BANK_NAME": null,
                        "BANK_DESCRIPTION": null,
                        "BANK_NUMBER": null,
                        "BANK_COUNTRY_CODE": null,
						"BRANCH_ID":null,
                        "BRANCH_NAME": null,
                        "ALTERNATE_BRANCH_NAME": null,
                        "BRANCH_NUMBER": null,
                        "BRANCH_DESCRIPTION": null,
                        "EFT_SWIFT_CODE": null,
                        "BIC": null,
						"BANK_ACCOUNT_ID":null,
                        "BANK_ACCOUNT_NAME": null,
                        "ALTERNATE_ACCOUNT_NAME": null,
                        "SHORT_ACCOUNT_NAME": null,
                        "BANK_ACCOUNT_NUMBER": null,
                        "CURRENCY_CODE": null,
                        "IBAN": null,
                        "CHECK_DIGITS": null,
                        "MULTI_CURRENCY_ALLOWED_FLAG":null,
                        "ACCOUNT_TYPE": null,
                        "ACCOUNT_SUFFIX": null,
                        "ACCOUNT_DESCRIPTION": null,
                        "ACCOUNT_COUNTRY_CODE": null,
                        "BANK_ACCOUNT_ATTRIBUTE3": null,
                        "PAN_NUMBER": null,
                        "GST_NUMBER": null
                    }
                ]
            }
        }
    }
}

Response Payload:
-----------------
{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "TIMESTAMP": "20-JAN-2023 15:34:21",
        "STATUS": "SUCCESS",
        "MESSAGE": "Supplier Site Created Successfully. Vendor Site ID:431386",
        "VENDOR_ID": "6686829",
        "VENDOR_NUMBER": "213887",
        "VENDOR_SITE_ID": "431386",
        "BANK_ID": {
            "@xsi:nil": "true"
        },
        "BRANCH_ID": {
            "@xsi:nil": "true"
        },
        "BANK_ACCOUNT_ID": {
            "@xsi:nil": "true"
        }
    }
}

/*******************************************************************************************************************/

Case 3: Existing Supplier Site new bank, new branch, new account

Supplier: MAHINDRRA SUP
Supplier Site:  CHENNAI
Bank: MAHINDRRA AXIS Bank
Bank Branch:MAHINDRRA AXIS BANK BRANCH
Bank Account Name:MAHINDRRA AXIS BANK ACCOUNT
Bank Account Number:MAHINDRRAAXIS1234567890

Vendor ID,Vendor Name ,Vendor Number, Vendor Site ID  and Vendor Site code is mandatory

Request Payload:
----------------
{
    "CREATE_SUPPLIER_ALL_MASTER_Input": {
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "RESTHeader": {
            "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
        },
        "InputParameters": {
            "DATA": {
                "DATA_ITEM": [
                    {
                        "DATA_SOURCE": "BAZ",
                        "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
						"VENDOR_ID": 6686829,
                        "VENDOR_NAME": "MAHINDRRA SUP",
                        "VENDOR_NUMBER": "213887",
                        "VENDOR_ALTERNATE_NAME": "MAHINDRRA SUP ALT",
                        "VENDOR_TYPE": "VENDOR",
                        "VENDOR_PAYMENT_TERMS": "IMMEDIATE",
                        "ENABLED_FLAG": "Y",
                        "ONE_TIME_FLAG": "Y",
                        "VDR_CUSTOMER_NUMBER": null,
                        "PARENT_VENDOR_ID": null,
                        "MIN_ORDER_AMOUNT": null,
                        "SET_OF_BOOKS_NAME": null,
                        "PAY_GROUP_LOOKUP_CODE": null,
                        "VDR_PAYMENT_PRIORITY": 99,
                        "VDR_INVOICE_CURRENCY_CODE": null,
                        "VDR_PAYMENT_CURRENCY_CODE": null,
                        "INVOICE_AMOUNT_LIMIT": null,
                        "VDR_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDR_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "HOLD_REASON": null,
                        "HOLD_FLAG": null,
                        "HOLD_DATE": null,
                        "VDR_START_DATE_ACTIVE":null,
                        "VDR_END_DATE_ACTIVE":null,
                        "VENDOR_ATTRIBUTE_CATEGORY": null,
                        "VENDOR_ATTRIBUTE1": null,
                        "VENDOR_ATTRIBUTE2": null,
                        "VENDOR_ATTRIBUTE15": "Y",
                        "NI_NUMBER": null,
                        "EDI_PAYMENT_METHOD": null,
                        "URL": null,
                        "REMITTANCE_EMAIL": null,
                        "CEO_NAME": null,
                        "CEO_TITLE": null,
						"VENDOR_SITE_ID":431385,
                        "VENDOR_SITE_CODE": "CHENNAI",
                        "VENDOR_SITE_CODE_ALT": "ALT_CHENNAI",
                        "ADDRESS_LINE_1": "ADDRESS LINE19223",
                        "ADDRESS_LINE_2": "ADDRESS LINE2",
                        "ADDRESS_LINE_3": "ADDRESS LINE3",
                        "ADDRESS_LINE_4": "ADDRESS LINE4",
                        "CITY": "TAMIL NADU",
                        "STATE": "TAMIL NADU",
                        "ZIP": "606601",
                        "PROVINCE": null,
                        "COUNTRY": "IN",
                        "PURCHASING_SITE_FLAG": "Y",
                        "RFQ_ONLY_SITE_FLAG": "Y",
                        "PAY_SITE_FLAG": "Y",
                        "PRIMARY_PAY_SITE_FLAG": "N",
                        "VDRS_INVOICE_CURRENCY_CODE": null,
                        "VDRS_PAYMENT_CURRENCY_CODE": null,
                        "VDRS_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_REASON": null,
                        "PHONE_NUMBER": "1234567831",
                        "EMAIL_ADDRESS": "abc1@gmail.com",
                        "DUNS_NUMBER": null,
                        "VDRS_PAYMENT_PRIORITY": null,
                        "VDRS_CUSTOMER_NUMBER": null,
                        "AREA_CODE": null,
                        "FAX": null,
                        "FAX_AREA_CODE": null,
                        "LIABILITY_ACCOUNT":null,
                        "PREPAYMENT_ACCOUNT":null,
                        "BILLS_PAYABLE_ACCOUNT":null,
                        "VENDOR_SITE_PAYMENT_TERMS": "IMMEDIATE",
                        "LEGAL_BUSINESS_NAME": null,
                        "VDRS_INVOICE_AMOUNT_LIMIT": null,
                        "INACTIVE_DATE": null,
							"BANK_ID":null,
                        "BANK_NAME": "MAHINDRRA AXIS Bank",
                        "ALTERNATE_BANK_NAME": "MAHINDRRA AXIS Bank",
                        "SHORT_BANK_NAME": "AXIS",
                        "BANK_DESCRIPTION": "MAHINDRRA AXIS Bank",
                        "BANK_NUMBER": null,
                        "BANK_COUNTRY_CODE": "IN",
						"BRANCH_ID":null,
                        "BRANCH_NAME": "MAHINDRRA AXIS BANK BRANCH",
                        "ALTERNATE_BRANCH_NAME": "MAHINDRRA AXIS BANK BRANCH Alt",
                        "BRANCH_NUMBER": null,
                        "BRANCH_DESCRIPTION": "MAHINDRRA AXIS BANK BRANCH",
                        "EFT_SWIFT_CODE": null,
                        "BIC": null,
						"BANK_ACCOUNT_ID":null,
                        "BANK_ACCOUNT_NAME": "MAHINDRRA AXIS BANK ACCOUNT",
                        "ALTERNATE_ACCOUNT_NAME": "MAHINDRRA AXIS BANK ACCOUNT ALT",
                        "SHORT_ACCOUNT_NAME": null,
                        "BANK_ACCOUNT_NUMBER": "MAHINDRRAAXIS1234567892",
                        "CURRENCY_CODE": "INR",
                        "IBAN": null,
                        "CHECK_DIGITS": null,
                        "MULTI_CURRENCY_ALLOWED_FLAG": "Y",
                        "ACCOUNT_TYPE": null,
                        "ACCOUNT_SUFFIX": null,
                        "ACCOUNT_DESCRIPTION": null,
                        "ACCOUNT_COUNTRY_CODE": "IN",
                        "BANK_ACCOUNT_ATTRIBUTE3": "IFSC1234",
                        "PAN_NUMBER": "ABCDE1234M",
                        "GST_NUMBER": "GST1234567898"
                    }
                ]
            }
        }
    }
}

Response Payload:
------------------
{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "TIMESTAMP": "20-JAN-2023 15:39:04",
        "STATUS": "SUCCESS",
        "MESSAGE": {
            "@xsi:nil": "true"
        },
        "VENDOR_ID": "6686829",
        "VENDOR_NUMBER": "213887",
        "VENDOR_SITE_ID": "431385",
        "BANK_ID": "7451152",
        "BRANCH_ID": "7451154",
        "BANK_ACCOUNT_ID": "142056"
    }
}

==================================================================================================

Case 4: Existing Supplier New Site, new bank, new branch, new bank account

Supplier: MAHINDRRA SUP
Supplier Site:  BANGALORE
Bank: MAHINDRRA YES Bank
Bank Branch:MAHINDRRA YES BANK BRANCH
Bank Account Name:MAHINDRRA YES BANK ACCOUNT
Bank Account Number:MAHINDRRAYES1234567890

Vendor ID,Vendor Name and Vendor Number is mandatory

Request Payload:
----------------
{
    "CREATE_SUPPLIER_ALL_MASTER_Input": {
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "RESTHeader": {
            "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
        },
        "InputParameters": {
            "DATA": {
                "DATA_ITEM": [
                    {
                        "DATA_SOURCE": "BAZ",
                        "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
						"VENDOR_ID": 6686829,
                        "VENDOR_NAME": "MAHINDRRA SUP",
                        "VENDOR_NUMBER": "213887",
                        "VENDOR_ALTERNATE_NAME": "MAHINDRRA SUP ALT",
                        "VENDOR_TYPE": "VENDOR",
                        "VENDOR_PAYMENT_TERMS": "IMMEDIATE",
                        "ENABLED_FLAG": "Y",
                        "ONE_TIME_FLAG": "Y",
                        "VDR_CUSTOMER_NUMBER": null,
                        "PARENT_VENDOR_ID": null,
                        "MIN_ORDER_AMOUNT": null,
                        "SET_OF_BOOKS_NAME": null,
                        "PAY_GROUP_LOOKUP_CODE": null,
                        "VDR_PAYMENT_PRIORITY": 99,
                        "VDR_INVOICE_CURRENCY_CODE": null,
                        "VDR_PAYMENT_CURRENCY_CODE": null,
                        "INVOICE_AMOUNT_LIMIT": null,
                        "VDR_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDR_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "HOLD_REASON": null,
                        "HOLD_FLAG": null,
                        "HOLD_DATE": null,
                        "VDR_START_DATE_ACTIVE":null,
                        "VDR_END_DATE_ACTIVE":null,
                        "VENDOR_ATTRIBUTE_CATEGORY": null,
                        "VENDOR_ATTRIBUTE1": null,
                        "VENDOR_ATTRIBUTE2": null,
                        "VENDOR_ATTRIBUTE15": "Y",
                        "NI_NUMBER": null,
                        "EDI_PAYMENT_METHOD": null,
                        "URL": null,
                        "REMITTANCE_EMAIL": null,
                        "CEO_NAME": null,
                        "CEO_TITLE": null,
						"VENDOR_SITE_ID":null,
                        "VENDOR_SITE_CODE": "BANGALORE",
                        "VENDOR_SITE_CODE_ALT": "ALT_BANGALORE",
                        "ADDRESS_LINE_1": "ADDRESS LINE19223",
                        "ADDRESS_LINE_2": "ADDRESS LINE2",
                        "ADDRESS_LINE_3": "ADDRESS LINE3",
                        "ADDRESS_LINE_4": "ADDRESS LINE4",
                        "CITY": "TAMIL NADU",
                        "STATE": "TAMIL NADU",
                        "ZIP": "606601",
                        "PROVINCE": null,
                        "COUNTRY": "IN",
                        "PURCHASING_SITE_FLAG": "Y",
                        "RFQ_ONLY_SITE_FLAG": "Y",
                        "PAY_SITE_FLAG": "Y",
                        "PRIMARY_PAY_SITE_FLAG": "N",
                        "VDRS_INVOICE_CURRENCY_CODE": null,
                        "VDRS_PAYMENT_CURRENCY_CODE": null,
                        "VDRS_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_REASON": null,
                        "PHONE_NUMBER": "1234567831",
                        "EMAIL_ADDRESS": "abc1@gmail.com",
                        "DUNS_NUMBER": null,
                        "VDRS_PAYMENT_PRIORITY": null,
                        "VDRS_CUSTOMER_NUMBER": null,
                        "AREA_CODE": null,
                        "FAX": null,
                        "FAX_AREA_CODE": null,
                        "LIABILITY_ACCOUNT":null,
                        "PREPAYMENT_ACCOUNT":null,
                        "BILLS_PAYABLE_ACCOUNT":null,
                        "VENDOR_SITE_PAYMENT_TERMS": "IMMEDIATE",
                        "LEGAL_BUSINESS_NAME": null,
                        "VDRS_INVOICE_AMOUNT_LIMIT": null,
                        "INACTIVE_DATE": null,
							"BANK_ID":null,
                        "BANK_NAME": "MAHINDRRA YES Bank",
                        "ALTERNATE_BANK_NAME": "MAHINDRRA YES Bank",
                        "SHORT_BANK_NAME": "YES",
                        "BANK_DESCRIPTION": "MAHINDRRA YES Bank",
                        "BANK_NUMBER": null,
                        "BANK_COUNTRY_CODE": "IN",
						"BRANCH_ID":null,
                        "BRANCH_NAME": "MAHINDRRA YES BANK BRANCH",
                        "ALTERNATE_BRANCH_NAME": "MAHINDRRA YES BANK BRANCH Alt",
                        "BRANCH_NUMBER": null,
                        "BRANCH_DESCRIPTION": "MAHINDRRA YES BANK BRANCH",
                        "EFT_SWIFT_CODE": null,
                        "BIC": null,
						"BANK_ACCOUNT_ID":null,
                        "BANK_ACCOUNT_NAME": "MAHINDRRA YES BANK ACCOUNT",
                        "ALTERNATE_ACCOUNT_NAME": "MAHINDRRA YES BANK ACCOUNT ALT",
                        "SHORT_ACCOUNT_NAME": null,
                        "BANK_ACCOUNT_NUMBER": "MAHINDRRAYES1234567892",
                        "CURRENCY_CODE": "INR",
                        "IBAN": null,
                        "CHECK_DIGITS": null,
                        "MULTI_CURRENCY_ALLOWED_FLAG": "Y",
                        "ACCOUNT_TYPE": null,
                        "ACCOUNT_SUFFIX": null,
                        "ACCOUNT_DESCRIPTION": null,
                        "ACCOUNT_COUNTRY_CODE": "IN",
                        "BANK_ACCOUNT_ATTRIBUTE3": "IFSCYES1234",
                        "PAN_NUMBER": "ABCDE1234M",
                        "GST_NUMBER": "GST1234567898"
                    }
                ]
            }
        }
    }
}

Response Payload:
-----------------
{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "TIMESTAMP": "20-JAN-2023 15:42:52",
        "STATUS": "SUCCESS",
        "MESSAGE": "Supplier Site Created Successfully. Vendor Site ID:431387,",
        "VENDOR_ID": "6686829",
        "VENDOR_NUMBER": "213887",
        "VENDOR_SITE_ID": "431387",
        "BANK_ID": "7451157",
        "BRANCH_ID": "7451159",
        "BANK_ACCOUNT_ID": "142057"
    }
}

/************************************************************************************************************/
Case 5: Existing supplier,bank,branch and bank account with new site(WIP)

Supplier: MAHINDRRA SUP
Supplier Site:  GOA
Bank: MAHINDRRA YES Bank
Bank Branch:MAHINDRRA YES BANK BRANCH
Bank Account Name:MAHINDRRA YES BANK ACCOUNT
Bank Account Number:MAHINDRRAYES1234567890

Vendor ID,Vendor Name,Vendor Number is Mandatory


Request Payload:
----------------
{
    "CREATE_SUPPLIER_ALL_MASTER_Input": {
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "RESTHeader": {
            "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
        },
        "InputParameters": {
            "DATA": {
                "DATA_ITEM": [
                    {
                        "DATA_SOURCE": "BAZ",
                        "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
						"VENDOR_ID": 6686829,
                        "VENDOR_NAME": "MAHINDRRA SUP",
                        "VENDOR_NUMBER": "213887",
                        "VENDOR_ALTERNATE_NAME": "MAHINDRRA SUP ALT",
                        "VENDOR_TYPE": "VENDOR",
                        "VENDOR_PAYMENT_TERMS": "IMMEDIATE",
                        "ENABLED_FLAG": "Y",
                        "ONE_TIME_FLAG": "Y",
                        "VDR_CUSTOMER_NUMBER": null,
                        "PARENT_VENDOR_ID": null,
                        "MIN_ORDER_AMOUNT": null,
                        "SET_OF_BOOKS_NAME": null,
                        "PAY_GROUP_LOOKUP_CODE": null,
                        "VDR_PAYMENT_PRIORITY": 99,
                        "VDR_INVOICE_CURRENCY_CODE": null,
                        "VDR_PAYMENT_CURRENCY_CODE": null,
                        "INVOICE_AMOUNT_LIMIT": null,
                        "VDR_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDR_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "HOLD_REASON": null,
                        "HOLD_FLAG": null,
                        "HOLD_DATE": null,
                        "VDR_START_DATE_ACTIVE":null,
                        "VDR_END_DATE_ACTIVE":null,
                        "VENDOR_ATTRIBUTE_CATEGORY": null,
                        "VENDOR_ATTRIBUTE1": null,
                        "VENDOR_ATTRIBUTE2": null,
                        "VENDOR_ATTRIBUTE15": "Y",
                        "NI_NUMBER": null,
                        "EDI_PAYMENT_METHOD": null,
                        "URL": null,
                        "REMITTANCE_EMAIL": null,
                        "CEO_NAME": null,
                        "CEO_TITLE": null,
						"VENDOR_SITE_ID":null,
                        "VENDOR_SITE_CODE": "GOA",
                        "VENDOR_SITE_CODE_ALT": "ALT_GOA",
                        "ADDRESS_LINE_1": "ADDRESS LINE19223",
                        "ADDRESS_LINE_2": "ADDRESS LINE2",
                        "ADDRESS_LINE_3": "ADDRESS LINE3",
                        "ADDRESS_LINE_4": "ADDRESS LINE4",
                        "CITY": "TAMIL NADU",
                        "STATE": "TAMIL NADU",
                        "ZIP": "606601",
                        "PROVINCE": null,
                        "COUNTRY": "IN",
                        "PURCHASING_SITE_FLAG": "Y",
                        "RFQ_ONLY_SITE_FLAG": "Y",
                        "PAY_SITE_FLAG": "Y",
                        "PRIMARY_PAY_SITE_FLAG": "N",
                        "VDRS_INVOICE_CURRENCY_CODE": null,
                        "VDRS_PAYMENT_CURRENCY_CODE": null,
                        "VDRS_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_REASON": null,
                        "PHONE_NUMBER": "1234567831",
                        "EMAIL_ADDRESS": "abc1@gmail.com",
                        "DUNS_NUMBER": null,
                        "VDRS_PAYMENT_PRIORITY": null,
                        "VDRS_CUSTOMER_NUMBER": null,
                        "AREA_CODE": null,
                        "FAX": null,
                        "FAX_AREA_CODE": null,
                        "LIABILITY_ACCOUNT":null,
                        "PREPAYMENT_ACCOUNT":null,
                        "BILLS_PAYABLE_ACCOUNT":null,
                        "VENDOR_SITE_PAYMENT_TERMS": "IMMEDIATE",
                        "LEGAL_BUSINESS_NAME": null,
                        "VDRS_INVOICE_AMOUNT_LIMIT": null,
                        "INACTIVE_DATE": null,
							"BANK_ID":null,
                        "BANK_NAME": "MAHINDRRA YES Bank",
                        "ALTERNATE_BANK_NAME": "MAHINDRRA YES Bank",
                        "SHORT_BANK_NAME": "YES",
                        "BANK_DESCRIPTION": "MAHINDRRA YES Bank",
                        "BANK_NUMBER": null,
                        "BANK_COUNTRY_CODE": "IN",
						"BRANCH_ID":null,
                        "BRANCH_NAME": "MAHINDRRA YES BANK BRANCH",
                        "ALTERNATE_BRANCH_NAME": "MAHINDRRA YES BANK BRANCH Alt",
                        "BRANCH_NUMBER": null,
                        "BRANCH_DESCRIPTION": "MAHINDRRA YES BANK BRANCH",
                        "EFT_SWIFT_CODE": null,
                        "BIC": null,
						"BANK_ACCOUNT_ID":null,
                        "BANK_ACCOUNT_NAME": "MAHINDRRA YES BANK ACCOUNT",
                        "ALTERNATE_ACCOUNT_NAME": "MAHINDRRA YES BANK ACCOUNT ALT",
                        "SHORT_ACCOUNT_NAME": null,
                        "BANK_ACCOUNT_NUMBER": "MAHINDRRAYES1234567892",
                        "CURRENCY_CODE": "INR",
                        "IBAN": null,
                        "CHECK_DIGITS": null,
                        "MULTI_CURRENCY_ALLOWED_FLAG": "Y",
                        "ACCOUNT_TYPE": null,
                        "ACCOUNT_SUFFIX": null,
                        "ACCOUNT_DESCRIPTION": null,
                        "ACCOUNT_COUNTRY_CODE": "IN",
                        "BANK_ACCOUNT_ATTRIBUTE3": "IFSCYES1234",
                        "PAN_NUMBER": "ABCDE1234M",
                        "GST_NUMBER": "GST1234567898"
                    }
                ]
            }
        }
    }
}


Response Payload:
-----------------
{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "TIMESTAMP": "20-JAN-2023 15:47:11",
        "STATUS": "SUCCESS",
        "MESSAGE": "Supplier Site Created Successfully. Vendor Site ID:431388,",
        "VENDOR_ID": "6686829",
        "VENDOR_NUMBER": "213887",
        "VENDOR_SITE_ID": "431388",
        "BANK_ID": "7451157",
        "BRANCH_ID": "7451159",
        "BANK_ACCOUNT_ID": "142057"
    }
}

/************************************************************************************************************/
Case 6: New supplier and Site, Without Passing bank,branch and bank account
=========================================================================

Supplier: MAHINDRRA SUP
Supplier Site:  GOA
Bank: null
Bank Branch: null
Bank Account Name: null
Bank Account Number: null

Vendor Name,Vendor Site Name is Mandatory

Request Payload:

{
    "CREATE_SUPPLIER_ALL_MASTER_Input": {
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "RESTHeader": {
            "@xmlns": "http://xmlns.oracle.com/apps/fnd/rest/header"
        },
        "InputParameters": {
            "DATA": {
                "DATA_ITEM": [
                    {
                        "DATA_SOURCE": "BAZ",
                        "OPERATING_UNIT": "CHOLAMANDALAM INVESTMENT AND FINANCE COMPANY LIMITED",
						"VENDOR_ID": null,
                        "VENDOR_NAME": "FEB_08_6",
                        "VENDOR_NUMBER": null,
                        "VENDOR_ALTERNATE_NAME": null,
                        "VENDOR_TYPE": "VENDOR",
                        "VENDOR_PAYMENT_TERMS": "IMMEDIATE",
                        "ENABLED_FLAG": "Y",
                        "ONE_TIME_FLAG": "Y",
                        "VDR_CUSTOMER_NUMBER": null,
                        "PARENT_VENDOR_ID": null,
                        "MIN_ORDER_AMOUNT": null,
                        "SET_OF_BOOKS_NAME": null,
                        "PAY_GROUP_LOOKUP_CODE": null,
                        "VDR_PAYMENT_PRIORITY": 99,
                        "VDR_INVOICE_CURRENCY_CODE": null,
                        "VDR_PAYMENT_CURRENCY_CODE": null,
                        "INVOICE_AMOUNT_LIMIT": null,
                        "VDR_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDR_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "HOLD_REASON": null,
                        "HOLD_FLAG": null,
                        "HOLD_DATE": null,
                        "VDR_START_DATE_ACTIVE":null,
                        "VDR_END_DATE_ACTIVE":null,
                        "VENDOR_ATTRIBUTE_CATEGORY": null,
                        "VENDOR_ATTRIBUTE1": null,
                        "VENDOR_ATTRIBUTE2": "Y",
                        "VENDOR_ATTRIBUTE15": "Y",
                        "NI_NUMBER": null,
                        "EDI_PAYMENT_METHOD": null,
                        "URL": null,
                        "REMITTANCE_EMAIL": null,
                        "CEO_NAME": null,
                        "CEO_TITLE": null,
						"VENDOR_SITE_ID":null,
                        "VENDOR_SITE_CODE": "FEB_08_6",
                        "VENDOR_SITE_CODE_ALT": "BNK_SITE",
                        "ADDRESS_LINE_1": "ADDRESS LINE19223",
                        "ADDRESS_LINE_2": "ADDRESS LINE2",
                        "ADDRESS_LINE_3": "ADDRESS LINE3",
                        "ADDRESS_LINE_4": "ADDRESS LINE4",
                        "CITY": "TAMIL NADU",
                        "STATE": "TAMIL NADU",
                        "ZIP": "606601",
                        "PROVINCE": null,
                        "COUNTRY": "IN",
                        "PURCHASING_SITE_FLAG": "Y",
                        "RFQ_ONLY_SITE_FLAG": "Y",
                        "PAY_SITE_FLAG": "Y",
                        "PRIMARY_PAY_SITE_FLAG": "N",
                        "VDRS_INVOICE_CURRENCY_CODE": null,
                        "VDRS_PAYMENT_CURRENCY_CODE": null,
                        "VDRS_HOLD_ALL_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_FUTURE_PAYMENTS_FLAG": null,
                        "VDRS_HOLD_REASON": null,
                        "PHONE_NUMBER": "1234567831",
                        "EMAIL_ADDRESS": "abc1@gmail.com",
                        "DUNS_NUMBER": null,
                        "VDRS_PAYMENT_PRIORITY": null,
                        "VDRS_CUSTOMER_NUMBER": null,
                        "AREA_CODE": null,
                        "FAX": null,
                        "FAX_AREA_CODE": null,
                        "LIABILITY_ACCOUNT":null,
                        "PREPAYMENT_ACCOUNT":null,
                        "BILLS_PAYABLE_ACCOUNT":null,
                        "VENDOR_SITE_PAYMENT_TERMS": "TDS",
                        "LEGAL_BUSINESS_NAME": null,
                        "VDRS_INVOICE_AMOUNT_LIMIT": null,
                        "INACTIVE_DATE": null,
						"BANK_ID":null,
                        "BANK_NAME": null,
                        "ALTERNATE_BANK_NAME": null,
                        "SHORT_BANK_NAME": null,
                        "BANK_DESCRIPTION": null,
                        "BANK_NUMBER": null,
                        "BANK_COUNTRY_CODE": null,
						"BRANCH_ID":null,
                        "BRANCH_NAME": null,
                        "ALTERNATE_BRANCH_NAME": null,
                        "BRANCH_NUMBER": null,
                        "BRANCH_DESCRIPTION": null,
                        "EFT_SWIFT_CODE": null,
                        "BIC": null,
						"BANK_ACCOUNT_ID":null,
                        "BANK_ACCOUNT_NAME": null,
                        "ALTERNATE_ACCOUNT_NAME": null,
                        "SHORT_ACCOUNT_NAME": null,
                        "BANK_ACCOUNT_NUMBER": null,
                        "CURRENCY_CODE": null,
                        "IBAN": null,
                        "CHECK_DIGITS": null,
                        "MULTI_CURRENCY_ALLOWED_FLAG": null,
                        "ACCOUNT_TYPE": null,
                        "ACCOUNT_SUFFIX": null,
                        "ACCOUNT_DESCRIPTION": null,
                        "ACCOUNT_COUNTRY_CODE": null,
                        "BANK_ACCOUNT_ATTRIBUTE3": null,
                        "PAN_NUMBER": "ABCDE1234J",
                        "GST_NUMBER": "GST1234567895"
                    }
                ]
            }
        }
    }
}

======================

RESPONSE:

{
    "OutputParameters": {
        "@xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "@xmlns": "http://xmlns.oracle.com/apps/ap/rest/crt_all_supplier_master/create_supplier_all_master/",
        "TIMESTAMP": "08-FEB-2023 16:04:08",
        "STATUS": "SUCCESS",
        "MESSAGE": {
            "@xsi:nil": "true"
        },
        "VENDOR_ID": "6689830",
        "VENDOR_NUMBER": "213936",
        "VENDOR_SITE_ID": "434367",
        "BANK_ID": {
            "@xsi:nil": "true"
        },
        "BRANCH_ID": {
            "@xsi:nil": "true"
        },
        "BANK_ACCOUNT_ID": {
            "@xsi:nil": "true"
        }
    }
}
